import Foundation

struct GeminiResult {
    let lang: String        // "vi" hoặc "en"
    let text: String        // câu gốc đã chỉnh lỗi nhận giọng
    let translation: String
}

enum GeminiError: LocalizedError {
    case http(Int, String)
    case badResponse

    var errorDescription: String? {
        switch self {
        case .http(let code, let body):
            switch code {
            case 429: return "hết hạn mức tạm thời (429)"
            case 503: return "model đang quá tải (503)"
            case 401, 403: return "key không hợp lệ hoặc không có quyền (\(code))"
            case 404: return "không tìm thấy model/địa chỉ (404): \(body)"
            default: return "lỗi \(code): \(body)"
            }
        case .badResponse:
            return "phản hồi không đọc được"
        }
    }
}

struct ProviderError: LocalizedError {
    let provider: String
    let underlying: Error
    var errorDescription: String? { "\(provider): \(underlying.localizedDescription)" }
}

// MARK: - Gọi từng nhà cung cấp
enum LLM {
    typealias Msg = (role: String, text: String)   // role: "user" | "model"

    static func complete(_ c: ProviderConfig, system: String, messages: [Msg],
                         json: Bool, temperature: Double?, timeout: TimeInterval) async throws -> String {
        switch c.id.kind {
        case .gemini:    return try await gemini(c, system, messages, json, temperature, timeout)
        case .anthropic: return try await anthropic(c, system, messages, timeout)
        case .openAI:    return try await openAI(c, system, messages, temperature, timeout)
        }
    }

    private static func post(_ url: URL, headers: [String: String], body: [String: Any],
                             timeout: TimeInterval) async throws -> [String: Any] {
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.timeoutInterval = timeout
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        for (k, v) in headers { req.setValue(v, forHTTPHeaderField: k) }
        req.httpBody = try JSONSerialization.data(withJSONObject: body)

        let (data, resp) = try await URLSession.shared.data(for: req)
        guard let http = resp as? HTTPURLResponse else { throw GeminiError.badResponse }
        guard http.statusCode == 200 else {
            let snippet = String((String(data: data, encoding: .utf8) ?? "").prefix(140))
            throw GeminiError.http(http.statusCode, snippet)
        }
        guard let obj = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw GeminiError.badResponse
        }
        return obj
    }

    private static func gemini(_ c: ProviderConfig, _ system: String, _ messages: [Msg],
                               _ json: Bool, _ temperature: Double?, _ timeout: TimeInterval) async throws -> String {
        var name = c.model
        if name.hasPrefix("models/") { name = String(name.dropFirst(7)) }
        guard let url = URL(string: "\(c.base)/models/\(name):generateContent") else { throw GeminiError.badResponse }

        let contents: [[String: Any]] = messages.map { ["role": $0.role, "parts": [["text": $0.text]]] }
        var gen: [String: Any] = [:]
        if let t = temperature { gen["temperature"] = t }
        if json { gen["responseMimeType"] = "application/json" }
        var body: [String: Any] = ["contents": contents, "generationConfig": gen]
        if !system.isEmpty { body["system_instruction"] = ["parts": [["text": system]]] }

        let root = try await post(url, headers: ["x-goog-api-key": c.key], body: body, timeout: timeout)
        guard let cands = root["candidates"] as? [[String: Any]],
              let content = cands.first?["content"] as? [String: Any],
              let parts = content["parts"] as? [[String: Any]] else { throw GeminiError.badResponse }
        let text = parts.filter { ($0["thought"] as? Bool) != true }
            .compactMap { $0["text"] as? String }.joined()
            .trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { throw GeminiError.badResponse }
        return text
    }

    private static func anthropic(_ c: ProviderConfig, _ system: String, _ messages: [Msg],
                                  _ timeout: TimeInterval) async throws -> String {
        guard let url = URL(string: c.base) else { throw GeminiError.badResponse }
        let msgs: [[String: Any]] = messages.map {
            ["role": $0.role == "model" ? "assistant" : "user", "content": $0.text]
        }
        var body: [String: Any] = ["model": c.model, "max_tokens": 1024, "messages": msgs]
        if !system.isEmpty { body["system"] = system }

        let root = try await post(url,
                                  headers: ["x-api-key": c.key, "anthropic-version": "2023-06-01"],
                                  body: body, timeout: timeout)
        guard let content = root["content"] as? [[String: Any]] else { throw GeminiError.badResponse }
        let text = content.compactMap { $0["text"] as? String }.joined()
            .trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { throw GeminiError.badResponse }
        return text
    }

    private static func openAI(_ c: ProviderConfig, _ system: String, _ messages: [Msg],
                               _ temperature: Double?, _ timeout: TimeInterval) async throws -> String {
        var base = c.base
        while base.hasSuffix("/") { base.removeLast() }
        let full = base.hasSuffix("/chat/completions") ? base : base + "/chat/completions"
        guard let url = URL(string: full) else { throw GeminiError.badResponse }

        var msgs: [[String: Any]] = []
        if !system.isEmpty { msgs.append(["role": "system", "content": system]) }
        msgs += messages.map { ["role": $0.role == "model" ? "assistant" : "user", "content": $0.text] }

        var body: [String: Any] = ["model": c.model, "messages": msgs]
        // Một số model (vd. dòng reasoning của OpenAI) không cho đổi temperature
        if let t = temperature, c.id != .openai { body["temperature"] = t }

        var headers: [String: String] = [:]
        if !c.key.isEmpty { headers["Authorization"] = "Bearer \(c.key)" }

        let root = try await post(url, headers: headers, body: body, timeout: timeout)
        guard let choices = root["choices"] as? [[String: Any]],
              let message = choices.first?["message"] as? [String: Any],
              let text = message["content"] as? String else { throw GeminiError.badResponse }
        let t = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !t.isEmpty else { throw GeminiError.badResponse }
        return t
    }
}

// MARK: - Thử lần lượt nhiều nhà cung cấp
enum Interpreter {
    static func run(_ providers: [ProviderConfig], system: String, messages: [LLM.Msg],
                    json: Bool, temperature: Double?, timeout: TimeInterval) async throws -> String {
        var last: Error?
        for c in providers {
            var attempts = 0
            while true {
                do {
                    return try await LLM.complete(c, system: system, messages: messages,
                                                  json: json, temperature: temperature, timeout: timeout)
                } catch {
                    if Task.isCancelled { throw error }
                    last = ProviderError(provider: c.id.shortName, underlying: error)
                    attempts += 1
                    // Chỉ có một nhà → thử lại một lần nếu lỗi tạm thời
                    if providers.count == 1, attempts < 2, isTransient(error) {
                        try? await Task.sleep(nanoseconds: 1_000_000_000)
                        continue
                    }
                    break
                }
            }
        }
        throw last ?? GeminiError.badResponse
    }

    private static func isTransient(_ e: Error) -> Bool {
        if let g = e as? GeminiError, case .http(let code, _) = g { return [429, 500, 502, 503, 504].contains(code) }
        return e is URLError
    }

    // MARK: Dịch + đoán ngôn ngữ
    static func translate(candidates: [(lang: String, text: String)],
                          context: [(lang: String, text: String)],
                          providers: [ProviderConfig]) async throws -> GeminiResult {
        let system = """
        You are a live interpreter between Vietnamese and English speakers in a face-to-face conversation.
        One or two speech recognizers heard the same audio; each assumed a different language. \
        The recognizer that assumed the wrong language usually outputs gibberish or phonetically similar nonsense.
        Tasks: (1) decide which language was really spoken, (2) lightly fix obvious recognition errors using the \
        conversation context, (3) translate into the other language (Vietnamese -> English, English -> Vietnamese) \
        naturally, the way a person would say it.
        Reply ONLY with JSON, no markdown: {"lang":"vi" or "en","text":"cleaned transcript in the spoken language","translation":"..."}
        """
        var user = ""
        if !context.isEmpty {
            user += "Recent conversation (oldest first):\n"
            for c in context { user += "- [\(c.lang)] \(c.text)\n" }
            user += "\n"
        }
        user += "Recognizer outputs:\n"
        for c in candidates {
            let label = c.lang == "vi" ? "Vietnamese recognizer" : "English recognizer"
            user += "- \(label): \"\(c.text)\"\n"
        }

        var text = try await run(providers, system: system, messages: [(role: "user", text: user)],
                                 json: true, temperature: 0.2, timeout: 15)
        text = text.replacingOccurrences(of: "```json", with: "").replacingOccurrences(of: "```", with: "")
        guard let s = text.firstIndex(of: "{"), let e = text.lastIndex(of: "}"), s < e,
              let obj = try JSONSerialization.jsonObject(with: Data(String(text[s...e]).utf8)) as? [String: Any],
              let translation = obj["translation"] as? String, !translation.isEmpty
        else { throw GeminiError.badResponse }

        let rawLang = (obj["lang"] as? String)?.lowercased() ?? candidates.first?.lang ?? "en"
        let lang = rawLang.hasPrefix("vi") ? "vi" : "en"
        let clean = (obj["text"] as? String).flatMap { $0.isEmpty ? nil : $0 } ?? candidates.first?.text ?? ""
        return GeminiResult(lang: lang, text: clean, translation: translation)
    }

    // MARK: Chat
    static func chat(history: [(role: String, text: String)], system: String,
                     providers: [ProviderConfig]) async throws -> String {
        try await run(providers, system: system, messages: history, json: false, temperature: 0.7, timeout: 45)
    }
}
