import Foundation

struct GeminiResult {
    let lang: String        // "vi" hoặc "en"
    let text: String        // câu gốc đã chỉnh lỗi nhận giọng
    let translation: String
}

enum GeminiError: LocalizedError {
    case http(Int, String)
    case badResponse

    var errorDescription: String? {
        switch self {
        case .http(let code, let body):
            switch code {
            case 429: return "hết hạn mức tạm thời (429)"
            case 503: return "model đang quá tải (503)"
            case 401, 403: return "key không hợp lệ hoặc không có quyền (\(code))"
            case 404: return "không tìm thấy model/địa chỉ (404): \(body)"
            default: return "lỗi \(code): \(body)"
            }
        case .badResponse:
            return "phản hồi không đọc được"
        }
    }
}

struct ProviderError: LocalizedError {
    let provider: String
    let underlying: Error
    var errorDescription: String? { "\(provider): \(underlying.localizedDescription)" }
}

// MARK: - Gọi từng nhà cung cấp
enum LLM {
    typealias Msg = (role: String, text: String)   // role: "user" | "model"

    static func complete(_ c: ProviderConfig, system: String, messages: [Msg],
                         json: Bool, temperature: Double?, timeout: TimeInterval) async throws -> String {
        switch c.id.kind {
        case .gemini:    return try await gemini(c, system, messages, json, temperature, timeout)
        case .anthropic: return try await anthropic(c, system, messages, timeout)
        case .openAI:    return try await openAI(c, system, messages, temperature, timeout)
        }
    }

    private static func post(_ url: URL, headers: [String: String], body: [String: Any],
                             timeout: TimeInterval) async throws -> [String: Any] {
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.timeoutInterval = timeout
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        for (k, v) in headers { req.setValue(v, forHTTPHeaderField: k) }
        req.httpBody = try JSONSerialization.data(withJSONObject: body)

        let (data, resp) = try await URLSession.shared.data(for: req)
        guard let http = resp as? HTTPURLResponse else { throw GeminiError.badResponse }
        guard http.statusCode == 200 else {
            let snippet = String((String(data: data, encoding: .utf8) ?? "").prefix(140))
            throw GeminiError.http(http.statusCode, snippet)
        }
        guard let obj = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw GeminiError.badResponse
        }
        return obj
    }

    private static func gemini(_ c: ProviderConfig, _ system: String, _ messages: [Msg],
                               _ json: Bool, _ temperature: Double?, _ timeout: TimeInterval) async throws -> String {
        var name = c.model
        if name.hasPrefix("models/") { name = String(name.dropFirst(7)) }
        guard let url = URL(string: "\(c.base)/models/\(name):generateContent") else { throw GeminiError.badResponse }

        let contents: [[String: Any]] = messages.map { ["role": $0.role, "parts": [["text": $0.text]]] }
        var gen: [String: Any] = [:]
        if let t = temperature { gen["temperature"] = t }
        if json { gen["responseMimeType"] = "application/json" }
        var body: [String: Any] = ["contents": contents, "generationConfig": gen]
        if !system.isEmpty { body["system_instruction"] = ["parts": [["text": system]]] }

        let root = try await post(url, headers: ["x-goog-api-key": c.key], body: body, timeout: timeout)
        guard let cands = root["candidates"] as? [[String: Any]],
              let content = cands.first?["content"] as? [String: Any],
              let parts = content["parts"] as? [[String: Any]] else { throw GeminiError.badResponse }
        let text = parts.filter { ($0["thought"] as? Bool) != true }
            .compactMap { $0["text"] as? String }.joined()
            .trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { throw GeminiError.badResponse }
        return text
    }

    private static func anthropic(_ c: ProviderConfig, _ system: String, _ messages: [Msg],
                                  _ timeout: TimeInterval) async throws -> String {
        guard let url = URL(string: c.base) else { throw GeminiError.badResponse }
        let msgs: [[String: Any]] = messages.map {
            ["role": $0.role == "model" ? "assistant" : "user", "content": $0.text]
        }
        var body: [String: Any] = ["model": c.model, "max_tokens": 1024, "messages": msgs]
        if !system.isEmpty { body["system"] = system }

        let root = try await post(url,
                                  headers: ["x-api-key": c.key, "anthropic-version": "2023-06-01"],
                                  body: body, timeout: timeout)
        guard let content = root["content"] as? [[String: Any]] else { throw GeminiError.badResponse }
        let text = content.compactMap { $0["text"] as? String }.joined()
            .trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { throw GeminiError.badResponse }
        return text
    }

    private static func openAI(_ c: ProviderConfig, _ system: String, _ messages: [Msg],
                               _ temperature: Double?, _ timeout: TimeInterval) async throws -> String {
        var base = c.base
        while base.hasSuffix("/") { base.removeLast() }
        let full = base.hasSuffix("/chat/completions") ? base : base + "/chat/completions"
        guard let url = URL(string: full) else { throw GeminiError.badResponse }

        var msgs: [[String: Any]] = []
        if !system.isEmpty { msgs.append(["role": "system", "content": system]) }
        msgs += messages.map { ["role": $0.role == "model" ? "assistant" : "user", "content": $0.text] }

        var body: [String: Any] = ["model": c.model, "messages": msgs]
        // Một số model (vd. dòng reasoning của OpenAI) không cho đổi temperature
        if let t = temperature, c.id != .openai { body["temperature"] = t }

        var headers: [String: String] = [:]
        if !c.key.isEmpty { headers["Authorization"] = "Bearer \(c.key)" }

        let root = try await post(url, headers: headers, body: body, timeout: timeout)
        guard let choices = root["choices"] as? [[String: Any]],
              let message = choices.first?["message"] as? [String: Any],
              let text = message["content"] as? String else { throw GeminiError.badResponse }
        let t = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !t.isEmpty else { throw GeminiError.badResponse }
        return t
    }
}

// MARK: - Dò danh sách model
extension LLM {
    /// Lấy danh sách model mà key này dùng được (chỉ model chat/văn bản).
    static func listModels(_ c: ProviderConfig, timeout: TimeInterval = 15) async throws -> [String] {
        var headers: [String: String] = [:]
        let url: URL?
        switch c.id.kind {
        case .gemini:
            url = URL(string: "\(c.base)/models?pageSize=1000")
            headers["x-goog-api-key"] = c.key
        case .anthropic:
            var b = c.base
            if b.hasSuffix("/messages") { b.removeLast(9) }
            url = URL(string: b + "/models?limit=1000")
            headers["x-api-key"] = c.key
            headers["anthropic-version"] = "2023-06-01"
        case .openAI:
            var b = c.base
            while b.hasSuffix("/") { b.removeLast() }
            if b.hasSuffix("/chat/completions") { b.removeLast(17) }
            url = URL(string: b + "/models")
            if !c.key.isEmpty { headers["Authorization"] = "Bearer \(c.key)" }
        }
        guard let url else { throw GeminiError.badResponse }
        var req = URLRequest(url: url)
        req.timeoutInterval = timeout
        for (k, v) in headers { req.setValue(v, forHTTPHeaderField: k) }

        let (data, resp) = try await URLSession.shared.data(for: req)
        guard let http = resp as? HTTPURLResponse else { throw GeminiError.badResponse }
        guard http.statusCode == 200 else {
            let snippet = String((String(data: data, encoding: .utf8) ?? "").prefix(140))
            throw GeminiError.http(http.statusCode, snippet)
        }
        guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw GeminiError.badResponse
        }

        var ids: [String] = []
        if c.id.kind == .gemini {
            for m in (root["models"] as? [[String: Any]]) ?? [] {
                let methods = m["supportedGenerationMethods"] as? [String] ?? []
                guard methods.contains("generateContent"), var n = m["name"] as? String else { continue }
                if n.hasPrefix("models/") { n.removeFirst(7) }
                ids.append(n)
            }
        } else {
            ids = ((root["data"] as? [[String: Any]]) ?? []).compactMap { $0["id"] as? String }
        }

        let skip = ["embed", "whisper", "tts", "moderation", "guard", "dall", "image", "imagen",
                    "audio", "transcribe", "realtime", "rerank", "veo", "video", "aqa", "speech"]
        let out = ids.filter { id in
            let l = id.lowercased()
            return !skip.contains { l.contains($0) }
        }
        guard !out.isEmpty else { throw GeminiError.badResponse }
        return Array(Set(out)).sorted()
    }
}

// MARK: - Thử lần lượt nhiều nhà cung cấp
enum Interpreter {
    static func run(_ providers: [ProviderConfig], system: String, messages: [LLM.Msg],
                    json: Bool, temperature: Double?, timeout: TimeInterval) async throws -> String {
        var last: Error?
        for c in providers {
            var attempts = 0
            while true {
                do {
                    return try await LLM.complete(c, system: system, messages: messages,
                                                  json: json, temperature: temperature, timeout: timeout)
                } catch {
                    if Task.isCancelled { throw error }
                    last = ProviderError(provider: c.id.shortName, underlying: error)
                    attempts += 1
                    // Chỉ có một nhà → thử lại một lần nếu lỗi tạm thời
                    if providers.count == 1, attempts < 2, isTransient(error) {
                        try? await Task.sleep(nanoseconds: 1_000_000_000)
                        continue
                    }
                    break
                }
            }
        }
        throw last ?? GeminiError.badResponse
    }

    private static func isTransient(_ e: Error) -> Bool {
        if let g = e as? GeminiError, case .http(let code, _) = g { return [429, 500, 502, 503, 504].contains(code) }
        return e is URLError
    }

    // MARK: Dịch + đoán ngôn ngữ
    static func translate(candidates: [(lang: String, text: String)],
                          context: [(lang: String, text: String)],
                          providers: [ProviderConfig],
                          trusted: Bool = false) async throws -> GeminiResult {
        let baseSystem = """
        You are a live interpreter between Vietnamese and English speakers in a face-to-face conversation.
        One or two speech recognizers heard the same audio; each assumed a different language. \
        The recognizer that assumed the wrong language usually outputs gibberish or phonetically similar nonsense.
        Tasks: (1) decide which language was really spoken, (2) only fix a recognition error when it is obvious, \
        (3) translate into the other language (Vietnamese -> English, English -> Vietnamese) \
        naturally, the way a person would say it.
        Rules:
        - "text" must be based ONLY on the recognizer outputs of the current utterance. Never copy words from the \
        conversation history into "text" or "translation"; the history is only to disambiguate meaning.
        - The same sentence being repeated in the history does NOT mean the current utterance is the same.
        - Do not invent content. If an output is too short or unclear, keep it as is.
        - Translate the full meaning faithfully: keep names, numbers and tone; do not add, omit or explain anything.
        - Use the earlier conversation to resolve pronouns, dropped subjects (Vietnamese often omits them) and \
        ambiguous words, and keep terminology consistent across turns.
        - Translate idioms, slang and polite formulas by meaning, not word for word. \
        In Vietnamese choose pronouns and particles that fit the register and relationship; never leave stiff \
        translationese.
        Reply ONLY with JSON, no markdown: {"lang":"vi" or "en","text":"cleaned transcript in the spoken language","translation":"..."}
        """
        let notes = AppSettings.translationNotes()
        let system = baseSystem + "\n\nUser settings (follow them):\n" + notes
        var user = ""
        if !context.isEmpty {
            user += "Earlier conversation, for reference only (oldest first):\n"
            for c in context { user += "- [\(c.lang)] \(c.text)\n" }
            user += "\n"
        }
        user += "Current utterance, recognizer outputs:\n"
        if trusted {
            user += "(Transcript from Whisper, highly accurate. Keep it unchanged unless a word is clearly wrong.)\n"
        } else if candidates.count == 1 {
            user += "(Only one recognizer was used, so the speaker is using its language.)\n"
        }
        for c in candidates {
            let label = c.lang == "vi" ? "Vietnamese recognizer" : "English recognizer"
            user += "- \(label): \"\(c.text)\"\n"
        }

        func ask(_ prompt: String) async throws -> GeminiResult {
            var text = try await run(providers, system: system, messages: [(role: "user", text: prompt)],
                                     json: true, temperature: 0.1, timeout: 15)
            text = text.replacingOccurrences(of: "```json", with: "").replacingOccurrences(of: "```", with: "")
            guard let s = text.firstIndex(of: "{"), let e = text.lastIndex(of: "}"), s < e,
                  let obj = try JSONSerialization.jsonObject(with: Data(String(text[s...e]).utf8)) as? [String: Any],
                  let translation = obj["translation"] as? String, !translation.isEmpty
            else { throw GeminiError.badResponse }

            let rawLang = (obj["lang"] as? String)?.lowercased() ?? candidates.first?.lang ?? "en"
            let lang = rawLang.hasPrefix("vi") ? "vi" : "en"
            let clean = (obj["text"] as? String).flatMap { $0.isEmpty ? nil : $0 } ?? candidates.first?.text ?? ""
            return GeminiResult(lang: lang, text: clean, translation: translation)
        }

        // Câu đã chỉnh phải còn giống ít nhất một bản nhận giọng; nếu không là model đang chép lại lịch sử.
        func isFaithful(_ r: GeminiResult) -> Bool {
            candidates.contains { similarity($0.text, r.text) >= 0.5 }
        }

        let first = try await ask(user)
        if isFaithful(first) { return first }

        // Thử lại một lần, bỏ lịch sử hội thoại.
        if !context.isEmpty {
            var bare = "Current utterance, recognizer outputs:\n"
            if trusted {
                bare += "(Transcript from Whisper, highly accurate. Keep it unchanged unless a word is clearly wrong.)\n"
            } else if candidates.count == 1 {
                bare += "(Only one recognizer was used, so the speaker is using its language.)\n"
            }
            for c in candidates {
                let label = c.lang == "vi" ? "Vietnamese recognizer" : "English recognizer"
                bare += "- \(label): \"\(c.text)\"\n"
            }
            if let second = try? await ask(bare), isFaithful(second) { return second }
        }
        // Vẫn lệch → báo lỗi để dùng dịch offline trên đúng câu nhận được.
        throw GeminiError.badResponse
    }

    // Độ giống 0...1 giữa hai chuỗi (không phân biệt hoa thường và dấu).
    private static func similarity(_ a: String, _ b: String) -> Double {
        func norm(_ s: String) -> [Character] {
            Array(s.folding(options: [.diacriticInsensitive, .caseInsensitive], locale: Locale(identifier: "vi"))
                .replacingOccurrences(of: "đ", with: "d")
                .filter { $0.isLetter || $0.isNumber })
        }
        let x = norm(a), y = norm(b)
        if x.isEmpty || y.isEmpty { return x.isEmpty && y.isEmpty ? 1 : 0 }
        var prev = Array(0...y.count)
        for i in 1...x.count {
            var cur = [i] + Array(repeating: 0, count: y.count)
            for j in 1...y.count {
                cur[j] = min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (x[i - 1] == y[j - 1] ? 0 : 1))
            }
            prev = cur
        }
        return 1 - Double(prev[y.count]) / Double(max(x.count, y.count))
    }

    // MARK: Chat
    static func chat(history: [(role: String, text: String)], system: String,
                     providers: [ProviderConfig]) async throws -> String {
        try await run(providers, system: system, messages: history, json: false, temperature: 0.7, timeout: 45)
    }
}
