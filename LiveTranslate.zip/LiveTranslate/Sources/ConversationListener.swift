import Foundation
import Speech
import AVFoundation

struct Candidate {
    let lang: String   // "vi" / "en"
    let text: String
    let score: Float
}

final class AudioMeter: ObservableObject {
    @Published var level: CGFloat = 0
}

final class Lane {
    let locale: Locale
    let recognizer: SFSpeechRecognizer
    let request = SFSpeechAudioBufferRecognitionRequest()
    var task: SFSpeechRecognitionTask?
    var text = ""
    var score: Float = 0
    var done = false
    var code: String { locale.language.languageCode?.identifier ?? "en" }

    init(locale: Locale, recognizer: SFSpeechRecognizer) {
        self.locale = locale
        self.recognizer = recognizer
        request.shouldReportPartialResults = true
    }
}

final class Segment {
    var lanes: [Lane] = []
    let start = Date()
    var ending = false
    var emitted = false

    var best: Lane? {
        let c = lanes.filter { !$0.text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
        return c.max { a, b in
            a.score == b.score ? a.text.count < b.text.count : a.score < b.score
        }
    }
}

/// Nghe liên tục, chạy song song nhận giọng nói Việt + Anh trên cùng một luồng âm thanh,
/// ngắt câu theo khoảng lặng, rồi chọn ngôn ngữ có độ tin cậy cao hơn cho mỗi câu.
final class ConversationListener: ObservableObject {
    @Published var liveText = ""
    @Published var liveLang = "vi"
    @Published var isRunning = false
    @Published var status = ""
    let meter = AudioMeter()

    var onUtterance: (([Candidate]) -> Void)?   // các bản nhận giọng, tốt nhất đứng đầu
    var locales: [Locale] = [Locale(identifier: "vi-VN"), Locale(identifier: "en-US")]

    private let engine = AVAudioEngine()
    private let lock = NSLock()
    private var requests: [SFSpeechAudioBufferRecognitionRequest] = []
    private var current: Segment?
    private var silenceTimer: Timer?

    func authorize(_ done: @escaping (Bool) -> Void) {
        SFSpeechRecognizer.requestAuthorization { status in
            AVAudioApplication.requestRecordPermission { granted in
                DispatchQueue.main.async { done(status == .authorized && granted) }
            }
        }
    }

    func start() {
        guard !isRunning else { return }
        do {
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.playAndRecord, mode: .default,
                                    options: [.defaultToSpeaker, .allowBluetooth])
            try session.setActive(true)

            let input = engine.inputNode
            input.removeTap(onBus: 0)
            input.installTap(onBus: 0, bufferSize: 2048,
                             format: input.outputFormat(forBus: 0)) { [weak self] buffer, _ in
                guard let self else { return }
                self.lock.lock(); let reqs = self.requests; self.lock.unlock()
                for r in reqs { r.append(buffer) }
                if let ch = buffer.floatChannelData?[0] {
                    let n = Int(buffer.frameLength)
                    var sum: Float = 0
                    for i in 0..<n { sum += ch[i] * ch[i] }
                    let rms = sqrt(sum / Float(max(n, 1)))
                    let lvl = CGFloat(min(1, rms * 9))
                    DispatchQueue.main.async { self.meter.level = self.meter.level * 0.5 + lvl * 0.5 }
                }
            }
            engine.prepare()
            try engine.start()
            isRunning = true
            status = ""
            beginSegment()
        } catch {
            status = "Lỗi micro: \(error.localizedDescription)"
        }
    }

    func stop() {
        guard isRunning else { return }
        isRunning = false
        silenceTimer?.invalidate()
        if let seg = current { emit(seg) }
        current = nil
        engine.stop()
        engine.inputNode.removeTap(onBus: 0)
        lock.lock(); requests = []; lock.unlock()
        liveText = ""
        status = ""
        meter.level = 0
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
    }

    // MARK: - Segments

    private func beginSegment() {
        let seg = Segment()
        seg.lanes = locales.compactMap { loc in
            guard let rec = SFSpeechRecognizer(locale: loc), rec.isAvailable else { return nil }
            let lane = Lane(locale: loc, recognizer: rec)
            lane.task = rec.recognitionTask(with: lane.request) { [weak self] result, error in
                let text = result?.bestTranscription.formattedString
                let score = result.map { Self.confidence($0.bestTranscription) }
                let finished = (result?.isFinal ?? false) || (result == nil && error != nil)
                DispatchQueue.main.async {
                    self?.handle(seg, lane, text, score, finished)
                }
            }
            return lane
        }
        if seg.lanes.isEmpty { status = "Ngôn ngữ chưa khả dụng trên máy này." }
        current = seg
        lock.lock(); requests = seg.lanes.map { $0.request }; lock.unlock()
    }

    private func handle(_ seg: Segment, _ lane: Lane, _ text: String?, _ score: Float?, _ finished: Bool) {
        guard !seg.emitted else { return }
        if let score { lane.score = score }
        if let text, !text.isEmpty, text != lane.text {
            lane.text = text
            textChanged(seg)
        }
        if finished {
            lane.done = true
            if seg.lanes.allSatisfy({ $0.done }) { emit(seg) }
        }
    }

    private func textChanged(_ seg: Segment) {
        guard seg === current, isRunning else { return }
        if let b = seg.best { liveText = b.text; liveLang = b.code }
        silenceTimer?.invalidate()
        silenceTimer = Timer.scheduledTimer(withTimeInterval: 0.9, repeats: false) { [weak self] _ in
            self?.endSegment()
        }
        if Date().timeIntervalSince(seg.start) > 25 { endSegment() }
    }

    /// Hết một câu: chốt câu cũ ở nền, mở ngay câu mới để không mất chữ.
    private func endSegment() {
        guard isRunning, let seg = current, !seg.ending else { return }
        seg.ending = true
        silenceTimer?.invalidate()
        seg.lanes.forEach { $0.request.endAudio() }
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) { [weak self] in
            self?.emit(seg)
        }
        beginSegment()
    }

    private func emit(_ seg: Segment) {
        guard !seg.emitted else { return }
        seg.emitted = true
        let best = seg.best
        seg.lanes.forEach { $0.task?.cancel(); $0.task = nil }

        let wasCurrent = (seg === current)
        let cands = seg.lanes
            .filter { !$0.text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
            .sorted { a, b in a.score == b.score ? a.text.count > b.text.count : a.score > b.score }
            .map { Candidate(lang: $0.code,
                             text: $0.text.trimmingCharacters(in: .whitespacesAndNewlines),
                             score: $0.score) }
        if !cands.isEmpty { onUtterance?(cands) }
        if wasCurrent || current?.best == nil { liveText = "" }

        // Segment kết thúc do hết giờ/lỗi (không qua endSegment) thì mở lại.
        if wasCurrent && isRunning {
            current = nil
            let delay = (best == nil && Date().timeIntervalSince(seg.start) < 0.5) ? 1.0 : 0.0
            DispatchQueue.main.asyncAfter(deadline: .now() + delay) { [weak self] in
                guard let self, self.isRunning, self.current == nil else { return }
                self.beginSegment()
            }
        }
    }

    private static func confidence(_ t: SFTranscription) -> Float {
        let s = t.segments
        guard !s.isEmpty else { return 0 }
        return s.map { $0.confidence }.reduce(0, +) / Float(s.count)
    }
}
