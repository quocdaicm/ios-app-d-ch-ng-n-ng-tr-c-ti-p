import Foundation
import Speech
import AVFoundation

struct Candidate {
    let lang: String   // "vi" / "en"
    let text: String
    let score: Float
}

final class AudioMeter: ObservableObject {
    @Published var level: CGFloat = 0
}

final class Lane {
    let locale: Locale
    let recognizer: SFSpeechRecognizer
    let request = SFSpeechAudioBufferRecognitionRequest()
    var task: SFSpeechRecognitionTask?
    var text = ""
    var score: Float = 0
    var done = false
    var code: String { locale.language.languageCode?.identifier ?? "en" }

    init(locale: Locale, recognizer: SFSpeechRecognizer) {
        self.locale = locale
        self.recognizer = recognizer
        request.shouldReportPartialResults = true
    }
}

/// Âm thanh 16 kHz mono của một câu, để gửi cho Whisper.
final class AudioBox {
    var samples: [Int16] = []
    static let maxSamples = 16000 * 28
}

final class Segment {
    let audio = AudioBox()
    var lanes: [Lane] = []
    let start = Date()
    var ending = false
    var emitted = false

    var best: Lane? {
        let c = lanes.filter { !$0.text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
        return c.max { a, b in
            a.score == b.score ? a.text.count < b.text.count : a.score < b.score
        }
    }
}

/// Nghe liên tục, chạy song song nhận giọng nói Việt + Anh trên cùng một luồng âm thanh,
/// ngắt câu theo khoảng lặng, rồi chọn ngôn ngữ có độ tin cậy cao hơn cho mỗi câu.
final class ConversationListener: ObservableObject {
    @Published var liveText = ""
    @Published var liveLang = "vi"
    @Published var isRunning = false
    @Published var status = ""
    let meter = AudioMeter()

    /// true khi đã có Whisper: không cần đợi chữ chốt của iPhone nên ra bản dịch nhanh hơn.
    var fastMode = false
    var onUtterance: (([Candidate], Data?) -> Void)?   // các bản nhận giọng (tốt nhất đứng đầu) + âm thanh WAV
    /// "vi" hoặc "en" khi chỉ nghe một ngôn ngữ, nil khi để tự động.
    var forcedLang: String? {
        locales.count == 1 ? locales[0].language.languageCode?.identifier : nil
    }
    var locales: [Locale] = [Locale(identifier: "vi-VN"), Locale(identifier: "en-US")]

    private let engine = AVAudioEngine()
    private let lock = NSLock()
    private var requests: [SFSpeechAudioBufferRecognitionRequest] = []
    private var current: Segment?
    private var silenceTimer: Timer?
    private var watchdog: Timer?
    /// false = chạy song song Việt + Anh (mặc định). Nếu có tiếng mà hai bộ không ra chữ nào,
    /// tự chuyển sang true: chỉ chạy MỘT bộ mỗi lần và tự đổi ngôn ngữ qua lại.
    var sequential = false
    private var activeIdx = 0
    private var watchdogTrips = 0
    private var soundSince: Date?   // bắt đầu có tiếng mà chưa nhận ra chữ nào
    private var sink: AudioBox?
    private var converter: AVAudioConverter?
    private let outFormat = AVAudioFormat(commonFormat: .pcmFormatInt16, sampleRate: 16000,
                                          channels: 1, interleaved: true)!

    func authorize(_ done: @escaping (Bool) -> Void) {
        SFSpeechRecognizer.requestAuthorization { status in
            AVAudioApplication.requestRecordPermission { granted in
                DispatchQueue.main.async { done(status == .authorized && granted) }
            }
        }
    }

    func start() {
        guard !isRunning else { return }
        do {
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.playAndRecord, mode: .default,
                                    options: [.defaultToSpeaker, .allowBluetooth])
            try session.setActive(true)

            let input = engine.inputNode
            input.removeTap(onBus: 0)
            let inFormat = input.outputFormat(forBus: 0)
            converter = AVAudioConverter(from: inFormat, to: outFormat)
            input.installTap(onBus: 0, bufferSize: 2048,
                             format: inFormat) { [weak self] buffer, _ in
                guard let self, !Speaker.isSpeaking else { return }
                let pcm = self.downsample(buffer)
                self.lock.lock()
                let reqs = self.requests
                if let box = self.sink, !pcm.isEmpty {
                    box.samples.append(contentsOf: pcm)
                    if box.samples.count > AudioBox.maxSamples {
                        box.samples.removeFirst(box.samples.count - AudioBox.maxSamples)
                    }
                }
                self.lock.unlock()
                for r in reqs { r.append(buffer) }
                if let ch = buffer.floatChannelData?[0] {
                    let n = Int(buffer.frameLength)
                    var sum: Float = 0
                    for i in 0..<n { sum += ch[i] * ch[i] }
                    let rms = sqrt(sum / Float(max(n, 1)))
                    let lvl = CGFloat(min(1, rms * 9))
                    DispatchQueue.main.async {
                        self.meter.level = self.meter.level * 0.5 + lvl * 0.5
                        if lvl > 0.15, self.soundSince == nil { self.soundSince = Date() }
                    }
                }
            }
            engine.prepare()
            try engine.start()
            isRunning = true
            status = ""
            soundSince = nil
            watchdog?.invalidate()
            watchdog = Timer.scheduledTimer(withTimeInterval: 2, repeats: true) { [weak self] _ in
                guard let self, self.isRunning, let s = self.soundSince,
                      Date().timeIntervalSince(s) > 6 else { return }
                self.soundSince = nil
                self.watchdogTrips += 1
                if !self.sequential, self.locales.count > 1 {
                    self.sequential = true      // song song không ra chữ → chạy từng ngôn ngữ một
                    self.restartSegment()
                    return
                }
                if self.sequential, self.locales.count > 1, self.watchdogTrips < 4 {
                    self.switchLane()      // thử ngôn ngữ còn lại
                    return
                }
                if self.status.isEmpty {
                    self.status = "Có tiếng nhưng iPhone chưa nhận ra chữ. Kiểm tra mạng và Cài đặt > Siri (bật Đọc chính tả), rồi thử \"Chỉ Việt\"/\"Chỉ Anh\"."
                }
            }
            beginSegment()
        } catch {
            status = "Lỗi micro: \(error.localizedDescription)"
        }
    }

    func stop() {
        guard isRunning else { return }
        isRunning = false
        silenceTimer?.invalidate()
        watchdog?.invalidate(); watchdog = nil
        soundSince = nil
        if let seg = current { emit(seg) }
        current = nil
        engine.stop()
        engine.inputNode.removeTap(onBus: 0)
        lock.lock(); requests = []; sink = nil; lock.unlock()
        liveText = ""
        status = ""
        meter.level = 0
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
    }

    // MARK: - Segments

    private func beginSegment() {
        let seg = Segment()
        let use: [Locale] = (sequential && locales.count > 1) ? [locales[activeIdx % locales.count]] : locales
        seg.lanes = use.compactMap { loc in
            guard let rec = SFSpeechRecognizer(locale: loc), rec.isAvailable else { return nil }
            let lane = Lane(locale: loc, recognizer: rec)
            lane.task = rec.recognitionTask(with: lane.request) { [weak self] result, error in
                let text = result?.bestTranscription.formattedString
                let score = result.map { Self.confidence($0.bestTranscription) }
                let finished = (result?.isFinal ?? false) || (result == nil && error != nil)
                // Bỏ qua lỗi "không có tiếng nói" (1110) và huỷ; các lỗi khác sẽ hiện lên để biết vì sao không nhận được.
                var errText: String?
                if let e = error as NSError?, e.code != 1110, e.code != 301, e.code != 216,
                   !(e.domain == NSCocoaErrorDomain && e.code == NSUserCancelledError) {
                    errText = "Nhận giọng \(loc.language.languageCode?.identifier ?? "") lỗi (\(e.code)): \(e.localizedDescription)"
                }
                DispatchQueue.main.async {
                    if let errText, self?.isRunning == true, text == nil { self?.status = errText }
                    self?.handle(seg, lane, text, score, finished)
                }
            }
            return lane
        }
        if seg.lanes.isEmpty { status = "Ngôn ngữ chưa khả dụng trên máy này." }
        current = seg
        lock.lock(); requests = seg.lanes.map { $0.request }; sink = seg.audio; lock.unlock()
    }

    /// Đổi sang ngôn ngữ còn lại và mở lại câu hiện tại.
    private func switchLane() {
        guard locales.count > 1 else { return }
        activeIdx = (activeIdx + 1) % locales.count
        restartSegment()
    }

    private func restartSegment() {
        if let seg = current, !seg.emitted {
            seg.emitted = true
            seg.lanes.forEach { $0.task?.cancel(); $0.task = nil; $0.request.endAudio() }
            silenceTimer?.invalidate()
            current = nil
            beginSegment()
        }
    }

    /// Gợi ý ngôn ngữ của câu vừa dịch (Whisper/Gemini xác định) để câu kế tiếp nghe đúng ngôn ngữ.
    func preferLang(_ code: String) {
        guard sequential, locales.count > 1,
              let i = locales.firstIndex(where: { $0.language.languageCode?.identifier == code }) else { return }
        activeIdx = i
    }

    private func downsample(_ buffer: AVAudioPCMBuffer) -> [Int16] {
        guard let conv = converter else { return [] }
        let ratio = outFormat.sampleRate / buffer.format.sampleRate
        let cap = AVAudioFrameCount(Double(buffer.frameLength) * ratio) + 64
        guard let out = AVAudioPCMBuffer(pcmFormat: outFormat, frameCapacity: cap) else { return [] }
        var supplied = false
        var err: NSError?
        conv.convert(to: out, error: &err) { _, status in
            if supplied { status.pointee = .noDataNow; return nil }
            supplied = true
            status.pointee = .haveData
            return buffer
        }
        guard err == nil, let ch = out.int16ChannelData else { return [] }
        return Array(UnsafeBufferPointer(start: ch[0], count: Int(out.frameLength)))
    }

    private func handle(_ seg: Segment, _ lane: Lane, _ text: String?, _ score: Float?, _ finished: Bool) {
        guard !seg.emitted else { return }
        if let score { lane.score = score }
        if let text, !text.isEmpty, text != lane.text {
            if !status.isEmpty { status = "" }
            soundSince = nil
            watchdogTrips = 0
            lane.text = text
            textChanged(seg)
        }
        if finished {
            lane.done = true
            if seg.lanes.allSatisfy({ $0.done }) { emit(seg) }
        }
    }

    private func textChanged(_ seg: Segment) {
        guard seg === current, isRunning else { return }
        if let b = seg.best { liveText = b.text; liveLang = b.code }
        silenceTimer?.invalidate()
        silenceTimer = Timer.scheduledTimer(withTimeInterval: fastMode ? 0.7 : 0.9, repeats: false) { [weak self] _ in
            self?.endSegment()
        }
        if Date().timeIntervalSince(seg.start) > 25 { endSegment() }
    }

    /// Hết một câu: chốt câu cũ ở nền, mở ngay câu mới để không mất chữ.
    private func endSegment() {
        guard isRunning, let seg = current, !seg.ending else { return }
        seg.ending = true
        silenceTimer?.invalidate()
        seg.lanes.forEach { $0.request.endAudio() }
        DispatchQueue.main.asyncAfter(deadline: .now() + (fastMode ? 0.3 : 1.5)) { [weak self] in
            self?.emit(seg)
        }
        beginSegment()
    }

    private func emit(_ seg: Segment) {
        guard !seg.emitted else { return }
        seg.emitted = true
        let best = seg.best
        seg.lanes.forEach { $0.task?.cancel(); $0.task = nil }

        let wasCurrent = (seg === current)
        let cands = seg.lanes
            .filter { !$0.text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
            .sorted { a, b in a.score == b.score ? a.text.count > b.text.count : a.score > b.score }
            .map { Candidate(lang: $0.code,
                             text: $0.text.trimmingCharacters(in: .whitespacesAndNewlines),
                             score: $0.score) }
        if sequential, locales.count > 1, let b = best, b.score < 0.3 {
            activeIdx = (activeIdx + 1) % locales.count   // nghe ra chữ kém tin cậy → câu sau thử ngôn ngữ kia
        }
        if !cands.isEmpty {
            lock.lock(); let pcm = seg.audio.samples; lock.unlock()
            onUtterance?(cands, Whisper.wav(from: pcm))
        }
        if wasCurrent || current?.best == nil { liveText = "" }

        // Segment kết thúc do hết giờ/lỗi (không qua endSegment) thì mở lại.
        if wasCurrent && isRunning {
            current = nil
            let delay = (best == nil && Date().timeIntervalSince(seg.start) < 0.5) ? 1.0 : 0.0
            DispatchQueue.main.asyncAfter(deadline: .now() + delay) { [weak self] in
                guard let self, self.isRunning, self.current == nil else { return }
                self.beginSegment()
            }
        }
    }

    private static func confidence(_ t: SFTranscription) -> Float {
        let s = t.segments
        guard !s.isEmpty else { return 0 }
        return s.map { $0.confidence }.reduce(0, +) / Float(s.count)
    }
}
