import Foundation
import Translation

struct Utterance: Identifiable {
    let id = UUID()
    var lang: String          // "vi" hoặc "en"
    var original: String
    var translated: String?
    var needsApple: Bool      // true = dịch bằng Apple offline
}

@MainActor
final class ConversationStore: ObservableObject {
    @Published var items: [Utterance] = []
    @Published var liveOriginal = ""
    @Published var liveLang = "vi"
    @Published var liveTranslated = ""
    @Published var notice = ""
    @Published var tick = 0

    /// Được ContentView gán trước mỗi lần thêm câu (nil = không dùng Gemini).
    var providers: [ProviderConfig] = []

    private var inFlight = Set<UUID>()
    private var liveRequest: (text: String, lang: String)?

    func add(candidates: [Candidate]) {
        guard let best = candidates.first else { return }
        let context = items.suffix(4).map { (lang: $0.lang, text: $0.original) }
        let use = providers
        let item = Utterance(lang: best.lang, original: best.text,
                             translated: nil, needsApple: use.isEmpty)
        items.append(item)
        liveRequest = nil
        liveOriginal = ""
        liveTranslated = ""
        tick += 1

        guard !use.isEmpty else { return }
        let id = item.id
        let cands = candidates.map { (lang: $0.lang, text: $0.text) }
        Task { [weak self] in
            do {
                let r = try await Interpreter.translate(candidates: cands, context: context,
                                                        providers: use)
                guard let self, let i = self.items.firstIndex(where: { $0.id == id }) else { return }
                self.items[i].lang = r.lang
                if !r.text.isEmpty { self.items[i].original = r.text }
                self.items[i].translated = r.translation
                self.notice = ""
            } catch {
                guard let self, let i = self.items.firstIndex(where: { $0.id == id }) else { return }
                self.items[i].needsApple = true      // quay về dịch offline
                self.notice = "\(error.localizedDescription) — đang dùng dịch offline"
                self.tick += 1
            }
        }
    }

    func setLive(text: String, lang: String) {
        liveOriginal = text
        liveLang = lang
        if text.isEmpty {
            liveTranslated = ""
            liveRequest = nil
        } else {
            liveRequest = (text, lang)
            tick += 1
        }
    }

    func clear() {
        items = []
        liveOriginal = ""
        liveTranslated = ""
        liveRequest = nil
        notice = ""
    }

    /// Dịch offline (Apple) hàng đợi của một ngôn ngữ nguồn + dòng đang nói.
    func drain(_ session: TranslationSession, lang: String) async {
        while let idx = items.firstIndex(where: {
            $0.needsApple && $0.lang == lang && $0.translated == nil && !inFlight.contains($0.id)
        }) {
            let item = items[idx]
            inFlight.insert(item.id)
            do {
                let r = try await session.translate(item.original)
                if let i = items.firstIndex(where: { $0.id == item.id }) {
                    items[i].translated = r.targetText
                }
                inFlight.remove(item.id)
            } catch {
                inFlight.remove(item.id)
                if Task.isCancelled || error is CancellationError { return }
                if let i = items.firstIndex(where: { $0.id == item.id }) {
                    items[i].translated = "⚠️ \(error.localizedDescription)"
                }
            }
        }
        if let live = liveRequest, live.lang == lang {
            liveRequest = nil
            if let r = try? await session.translate(live.text), liveOriginal == live.text {
                liveTranslated = r.targetText
            }
        }
    }
}
