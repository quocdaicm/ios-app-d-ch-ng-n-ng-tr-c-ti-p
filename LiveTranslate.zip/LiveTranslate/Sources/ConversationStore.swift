import Foundation
import Translation

struct Utterance: Identifiable, Codable {
    var id = UUID()
    var lang: String          // "vi" hoặc "en"
    var original: String
    var translated: String?
    var needsApple: Bool      // true = dịch bằng Apple offline
}

@MainActor
final class ConversationStore: ObservableObject {
    @Published var items: [Utterance] = [] { didSet { scheduleSave() } }
    @Published var liveOriginal = ""
    @Published var liveLang = "vi"
    @Published var liveTranslated = ""
    @Published var notice = ""
    @Published var tick = 0

    /// Được ContentView gán trước mỗi lần thêm câu (nil = không dùng Gemini).
    var providers: [ProviderConfig] = []

    private var inFlight = Set<UUID>()
    private var saveTask: Task<Void, Never>?

    init() { load() }

    // MARK: Lưu và khôi phục hội thoại gần nhất
    private static var fileURL: URL {
        FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("conversation.json")
    }

    private func load() {
        guard let data = try? Data(contentsOf: Self.fileURL),
              let saved = try? JSONDecoder().decode([Utterance].self, from: data) else { return }
        items = saved.filter { $0.translated != nil }
    }

    private func scheduleSave() {
        let snapshot = Array(items.suffix(200))
        saveTask?.cancel()
        saveTask = Task {
            try? await Task.sleep(nanoseconds: 1_000_000_000)
            if Task.isCancelled { return }
            let url = Self.fileURL
            try? FileManager.default.createDirectory(at: url.deletingLastPathComponent(),
                                                     withIntermediateDirectories: true)
            if let data = try? JSONEncoder().encode(snapshot) { try? data.write(to: url, options: .atomic) }
        }
    }
    private var liveRequest: (text: String, lang: String)?

    func add(candidates: [Candidate], audio: Data? = nil, forced: String? = nil) {
        guard let best = candidates.first else { return }
        let context = items.suffix(8).map { (lang: $0.lang, text: $0.original) }
        let use = providers
        let useWhisper = audio != nil && Whisper.provider() != nil
        let item = Utterance(lang: best.lang, original: best.text,
                             translated: nil, needsApple: use.isEmpty)
        items.append(item)
        liveRequest = nil
        liveOriginal = ""
        liveTranslated = ""
        tick += 1

        guard !use.isEmpty else { return }
        let id = item.id
        let initial = candidates.map { (lang: $0.lang, text: $0.text) }
        Task { [weak self] in
            var cands = initial
            var trusted = false
            // Bước 1: nhận giọng chính xác bằng Whisper (nếu có), lỗi thì dùng chữ của iPhone.
            var whisperNote = ""
            if useWhisper, let audio {
                do {
                    let outcome = try await Whisper.transcribe(wav: audio, forced: forced)
                    switch outcome {
                    case .result(let r):
                        cands = [(lang: r.lang, text: r.text)]
                        trusted = true
                        guard let self, let i = self.items.firstIndex(where: { $0.id == id }) else { return }
                        self.items[i].lang = r.lang
                        self.items[i].original = r.text
                    case .noSpeech:
                        guard let self else { return }
                        self.items.removeAll { $0.id == id }
                        self.tick += 1
                        return
                    case .unsupportedLanguage:
                        break
                    }
                } catch {
                    whisperNote = "Whisper lỗi (\(error.localizedDescription)) — dùng nhận giọng của iPhone"
                }
            }
            // Bước 2: dịch.
            do {
                let r = try await Interpreter.translate(candidates: cands, context: context,
                                                        providers: use, trusted: trusted)
                guard let self, let i = self.items.firstIndex(where: { $0.id == id }) else { return }
                self.items[i].lang = r.lang
                if !r.text.isEmpty { self.items[i].original = r.text }
                self.items[i].translated = r.translation
                self.notice = whisperNote
                if AppSettings.autoSpeak {
                    Speaker.shared.speak(r.translation, lang: r.lang == "vi" ? "en" : "vi")
                }
            } catch {
                guard let self, let i = self.items.firstIndex(where: { $0.id == id }) else { return }
                self.items[i].needsApple = true      // quay về dịch offline
                self.notice = "\(error.localizedDescription) — đang dùng dịch offline"
                self.tick += 1
            }
        }
    }

    func setLive(text: String, lang: String) {
        liveOriginal = text
        liveLang = lang
        if text.isEmpty {
            liveTranslated = ""
            liveRequest = nil
        } else {
            liveRequest = (text, lang)
            tick += 1
        }
    }

    func clear() {
        items = []
        liveOriginal = ""
        liveTranslated = ""
        liveRequest = nil
        notice = ""
    }

    /// Dịch offline (Apple) hàng đợi của một ngôn ngữ nguồn + dòng đang nói.
    func drain(_ session: TranslationSession, lang: String) async {
        while let idx = items.firstIndex(where: {
            $0.needsApple && $0.lang == lang && $0.translated == nil && !inFlight.contains($0.id)
        }) {
            let item = items[idx]
            inFlight.insert(item.id)
            do {
                let r = try await session.translate(item.original)
                if let i = items.firstIndex(where: { $0.id == item.id }) {
                    items[i].translated = r.targetText
                }
                inFlight.remove(item.id)
            } catch {
                inFlight.remove(item.id)
                if Task.isCancelled || error is CancellationError { return }
                if let i = items.firstIndex(where: { $0.id == item.id }) {
                    items[i].translated = "⚠️ \(error.localizedDescription)"
                }
            }
        }
        if let live = liveRequest, live.lang == lang {
            liveRequest = nil
            if let r = try? await session.translate(live.text), liveOriginal == live.text {
                liveTranslated = r.targetText
            }
        }
    }
}
