import Foundation
import Security
import SwiftUI

// MARK: - Keychain
enum Keychain {
    private static let service = "LiveTranslate"

    static func set(_ value: String, for account: String) {
        let base: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        SecItemDelete(base as CFDictionary)
        guard !value.isEmpty else { return }
        var add = base
        add[kSecValueData as String] = Data(value.utf8)
        SecItemAdd(add as CFDictionary, nil)
    }

    static func get(_ account: String) -> String? {
        let q: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var out: AnyObject?
        guard SecItemCopyMatching(q as CFDictionary, &out) == errSecSuccess,
              let data = out as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }
}

// MARK: - Providers
enum ProviderKind { case gemini, anthropic, openAI }

enum ProviderID: String, CaseIterable, Identifiable {
    case gemini, groq, anthropic, openai, deepseek, mistral, openrouter, custom
    var id: String { rawValue }

    var name: String {
        switch self {
        case .gemini: return "Google Gemini"
        case .groq: return "Groq"
        case .anthropic: return "Claude (Anthropic)"
        case .openai: return "OpenAI"
        case .deepseek: return "DeepSeek"
        case .mistral: return "Mistral"
        case .openrouter: return "OpenRouter"
        case .custom: return "Tùy chỉnh (OpenAI-compatible)"
        }
    }
    var shortName: String {
        switch self {
        case .anthropic: return "Claude"
        case .custom: return "Tùy chỉnh"
        case .gemini: return "Gemini"
        default: return name
        }
    }
    var kind: ProviderKind {
        switch self {
        case .gemini: return .gemini
        case .anthropic: return .anthropic
        default: return .openAI
        }
    }
    var defaultBase: String {
        switch self {
        case .gemini: return "https://generativelanguage.googleapis.com/v1beta"
        case .anthropic: return "https://api.anthropic.com/v1/messages"
        case .openai: return "https://api.openai.com/v1"
        case .groq: return "https://api.groq.com/openai/v1"
        case .mistral: return "https://api.mistral.ai/v1"
        case .deepseek: return "https://api.deepseek.com/v1"
        case .openrouter: return "https://openrouter.ai/api/v1"
        case .custom: return ""
        }
    }
    var defaultModel: String {
        switch self {
        case .gemini: return "gemini-flash-latest"
        case .anthropic: return "claude-haiku-4-5-20251001"
        case .openai: return "gpt-4o-mini"
        case .groq: return "llama-3.3-70b-versatile"
        case .mistral: return "mistral-small-latest"
        case .deepseek: return "deepseek-chat"
        case .openrouter: return "meta-llama/llama-3.3-70b-instruct:free"
        case .custom: return ""
        }
    }
    var keyURL: URL? {
        switch self {
        case .gemini: return URL(string: "https://aistudio.google.com/apikey")
        case .groq: return URL(string: "https://console.groq.com/keys")
        case .anthropic: return URL(string: "https://console.anthropic.com/settings/keys")
        case .openai: return URL(string: "https://platform.openai.com/api-keys")
        case .deepseek: return URL(string: "https://platform.deepseek.com/api_keys")
        case .mistral: return URL(string: "https://console.mistral.ai/api-keys")
        case .openrouter: return URL(string: "https://openrouter.ai/keys")
        case .custom: return nil
        }
    }
    var note: String {
        switch self {
        case .gemini: return "Có gói miễn phí (giới hạn theo phút/ngày), không cần thẻ."
        case .groq: return "Có gói miễn phí, không cần thẻ, tốc độ rất nhanh."
        case .anthropic: return "Trả phí theo lượng dùng, cần nạp tiền trước. Chất lượng dịch và chat tốt."
        case .openai: return "Trả phí theo lượng dùng."
        case .deepseek: return "Giá rẻ, trả phí theo lượng dùng."
        case .mistral: return "Có gói miễn phí (có thể cần xác minh số điện thoại)."
        case .openrouter: return "Có một số model miễn phí (tên kết thúc bằng :free), giới hạn số yêu cầu mỗi ngày."
        case .custom: return "Dùng bất kỳ dịch vụ tương thích OpenAI (Ollama/LM Studio trên máy tính, Together…). Nhập Base URL kết thúc bằng /v1."
        }
    }
    var icon: String {
        switch self {
        case .gemini: return "sparkles"
        case .groq: return "bolt.fill"
        case .anthropic: return "asterisk"
        case .openai: return "circle.hexagongrid.fill"
        case .deepseek: return "water.waves"
        case .mistral: return "wind"
        case .openrouter: return "arrow.triangle.branch"
        case .custom: return "server.rack"
        }
    }
    var color: Color {
        switch self {
        case .gemini: return Color(red: 0.35, green: 0.5, blue: 1.0)
        case .groq: return Color(red: 1.0, green: 0.45, blue: 0.2)
        case .anthropic: return Color(red: 0.85, green: 0.5, blue: 0.35)
        case .openai: return Color(red: 0.2, green: 0.75, blue: 0.6)
        case .deepseek: return Color(red: 0.3, green: 0.4, blue: 0.95)
        case .mistral: return Color(red: 1.0, green: 0.65, blue: 0.1)
        case .openrouter: return Color(red: 0.55, green: 0.4, blue: 0.95)
        case .custom: return Color(red: 0.55, green: 0.6, blue: 0.7)
        }
    }

    // Tên khoá lưu trữ (Gemini giữ khoá cũ để không mất key đã nhập)
    fileprivate var keyAccount: String { self == .gemini ? "geminiKey" : "key.\(rawValue)" }
    fileprivate var enabledKey: String { self == .gemini ? "geminiEnabled" : "enabled.\(rawValue)" }
    fileprivate var modelKey: String { self == .gemini ? "geminiModel" : "model.\(rawValue)" }
    fileprivate var baseKey: String { "base.\(rawValue)" }
}

struct ProviderConfig {
    let id: ProviderID
    let key: String
    let model: String
    let base: String
}

enum ProviderSettings {
    private static var d: UserDefaults { .standard }

    static func key(_ p: ProviderID) -> String { Keychain.get(p.keyAccount) ?? "" }
    static func setKey(_ p: ProviderID, _ v: String) {
        Keychain.set(v.trimmingCharacters(in: .whitespacesAndNewlines), for: p.keyAccount)
    }

    static func enabled(_ p: ProviderID) -> Bool { d.object(forKey: p.enabledKey) as? Bool ?? true }
    static func setEnabled(_ p: ProviderID, _ v: Bool) { d.set(v, forKey: p.enabledKey) }

    static func model(_ p: ProviderID) -> String {
        let m = (d.string(forKey: p.modelKey) ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        return m.isEmpty ? p.defaultModel : m
    }
    static func setModel(_ p: ProviderID, _ v: String) {
        d.set(v.trimmingCharacters(in: .whitespacesAndNewlines), forKey: p.modelKey)
    }

    static func base(_ p: ProviderID) -> String {
        guard p == .custom else { return p.defaultBase }
        return (d.string(forKey: p.baseKey) ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
    }
    static func setBase(_ p: ProviderID, _ v: String) {
        d.set(v.trimmingCharacters(in: .whitespacesAndNewlines), forKey: p.baseKey)
    }

    static func order() -> [ProviderID] {
        let saved = (d.stringArray(forKey: "providerOrder") ?? []).compactMap { ProviderID(rawValue: $0) }
        return saved + ProviderID.allCases.filter { !saved.contains($0) }
    }
    static func saveOrder(_ o: [ProviderID]) { d.set(o.map { $0.rawValue }, forKey: "providerOrder") }

    /// nil nếu nhà này đang tắt hoặc thiếu key/base.
    static func config(_ p: ProviderID) -> ProviderConfig? {
        guard enabled(p) else { return nil }
        let k = key(p)
        let b = base(p)
        if p == .custom {
            guard !b.isEmpty, !model(p).isEmpty else { return nil }
        } else {
            guard !k.isEmpty else { return nil }
        }
        return ProviderConfig(id: p, key: k, model: model(p), base: b)
    }

    static func active() -> [ProviderConfig] { order().compactMap { config($0) } }
}

enum AppSettings {
    private static var d: UserDefaults { .standard }

    /// "natural" | "formal" | "casual"
    static var tone: String {
        get { d.string(forKey: "translateTone") ?? "natural" }
        set { d.set(newValue, forKey: "translateTone") }
    }
    /// Cách xưng hô, ví dụ: tôi xưng "em", gọi người kia là "anh".
    static var addressing: String {
        get { d.string(forKey: "translateAddressing") ?? "" }
        set { d.set(newValue, forKey: "translateAddressing") }
    }
    /// Bối cảnh cuộc nói chuyện, ví dụ: đi du lịch, hỏi đường; họp công việc.
    static var situation: String {
        get { d.string(forKey: "translateSituation") ?? "" }
        set { d.set(newValue, forKey: "translateSituation") }
    }
    /// Mỗi dòng một mục, ví dụ: Minh = giữ nguyên.
    static var glossary: String {
        get { d.string(forKey: "translateGlossary") ?? "" }
        set { d.set(newValue, forKey: "translateGlossary") }
    }

    /// Tự đọc to bản dịch. Mặc định tắt.
    static var autoSpeak: Bool {
        get { d.object(forKey: "autoSpeak") as? Bool ?? false }
        set { d.set(newValue, forKey: "autoSpeak") }
    }

    /// Các thiết lập dịch, ghép thành đoạn chỉ dẫn gửi cho AI.
    static func translationNotes() -> String {
        func clean(_ s: String, _ n: Int) -> String {
            String(s.trimmingCharacters(in: .whitespacesAndNewlines).prefix(n))
        }
        var lines: [String] = []
        switch tone {
        case "formal": lines.append("Register: polite and formal.")
        case "casual": lines.append("Register: casual and friendly, the way friends talk.")
        default: lines.append("Register: natural, polite everyday speech.")
        }
        let a = clean(addressing, 300)
        if !a.isEmpty { lines.append("Vietnamese pronouns and forms of address to use (the phone's owner is the speaker of the Vietnamese side): \(a)") }
        let sit = clean(situation, 400)
        if !sit.isEmpty { lines.append("Situation: \(sit)") }
        let g = clean(glossary, 2000)
        if !g.isEmpty { lines.append("Glossary (always follow these; \"keep\" means leave the term as written):\n\(g)") }
        return lines.joined(separator: "\n")
    }

    /// Dùng Whisper (Groq/OpenAI) để nhận giọng chính xác hơn. Mặc định bật.
    static var whisperEnabled: Bool {
        get { UserDefaults.standard.object(forKey: "whisperEnabled") as? Bool ?? true }
        set { UserDefaults.standard.set(newValue, forKey: "whisperEnabled") }
    }
    /// Để trống = model mặc định của nhà cung cấp.
    static var whisperModel: String {
        get { UserDefaults.standard.string(forKey: "whisperModel") ?? "" }
        set { UserDefaults.standard.set(newValue.trimmingCharacters(in: .whitespacesAndNewlines), forKey: "whisperModel") }
    }

    static func providers() -> [ProviderConfig] { ProviderSettings.active() }

    static func label() -> String? {
        let a = providers()
        guard let f = a.first else { return nil }
        return a.count > 1 ? "\(f.id.shortName) +\(a.count - 1)" : f.id.shortName
    }
}
