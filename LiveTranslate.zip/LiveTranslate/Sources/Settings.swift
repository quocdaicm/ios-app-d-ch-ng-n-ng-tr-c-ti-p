import Foundation
import Security

enum Keychain {
    private static let service = "LiveTranslate"

    static func set(_ value: String, for account: String) {
        let base: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        SecItemDelete(base as CFDictionary)
        guard !value.isEmpty else { return }
        var add = base
        add[kSecValueData as String] = Data(value.utf8)
        SecItemAdd(add as CFDictionary, nil)
    }

    static func get(_ account: String) -> String? {
        let q: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var out: AnyObject?
        guard SecItemCopyMatching(q as CFDictionary, &out) == errSecSuccess,
              let data = out as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }
}

enum AppSettings {
    static let defaultModel = "gemini-flash-latest"

    /// Trả về (key, model) nếu người dùng bật Gemini và đã nhập key.
    static func gemini() -> (key: String, model: String)? {
        let d = UserDefaults.standard
        let enabled = d.object(forKey: "geminiEnabled") as? Bool ?? true
        guard enabled,
              let key = Keychain.get("geminiKey")?.trimmingCharacters(in: .whitespacesAndNewlines),
              !key.isEmpty else { return nil }
        let m = (d.string(forKey: "geminiModel") ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        return (key, m.isEmpty ? defaultModel : m)
    }
}
