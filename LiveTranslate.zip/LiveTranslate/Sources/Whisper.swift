import Foundation

struct WhisperResult {
    let lang: String   // "vi" hoặc "en"
    let text: String
}

enum WhisperOutcome {
    case result(WhisperResult)
    case noSpeech              // chỉ có tiếng ồn/im lặng
    case unsupportedLanguage   // nghe ra ngôn ngữ khác Việt/Anh
}

/// Nhận giọng nói bằng Whisper qua Groq hoặc OpenAI (chính xác hơn nhận giọng của iPhone).
enum Whisper {
    /// Nhà cung cấp dùng được (Groq hoặc OpenAI, theo thứ tự trong Cài đặt) hoặc nil nếu chưa có / đã tắt.
    /// Key đã bị từ chối (401/403) trong lần chạy này: bỏ qua nhà đó cho đến khi bạn đổi key.
    private static var rejected: [ProviderID: String] = [:]

    /// Tất cả nhà dùng được cho Whisper (Groq/OpenAI) theo thứ tự ưu tiên, bỏ nhà có key bị từ chối.
    static func providers() -> [(cfg: ProviderConfig, model: String)] {
        guard AppSettings.whisperEnabled else { return [] }
        var out: [(cfg: ProviderConfig, model: String)] = []
        for id in ProviderSettings.order() where id == .groq || id == .openai {
            guard let c = ProviderSettings.config(id), rejected[id] != c.key else { continue }
            let custom = AppSettings.whisperModel.trimmingCharacters(in: .whitespacesAndNewlines)
            // Model tuỳ chỉnh chỉ dùng cho nhà đầu tiên; các nhà còn lại dùng model mặc định của họ.
            let model = (custom.isEmpty || !out.isEmpty) ? (id == .groq ? "whisper-large-v3" : "whisper-1") : custom
            out.append((c, model))
        }
        return out
    }

    static func provider() -> (cfg: ProviderConfig, model: String)? { providers().first }

    /// Thử lần lượt từng nhà; nhà nào lỗi (sai key, hết hạn mức…) thì chuyển sang nhà kế tiếp.
    static func transcribe(wav: Data, forced: String?, timeout: TimeInterval = 20) async throws -> WhisperOutcome {
        var last: Error = GeminiError.badResponse
        for (c, model) in providers() {
            do {
                return try await send(wav: wav, forced: forced, timeout: timeout, c: c, model: model)
            } catch {
                if let g = error as? GeminiError, case .http(let code, _) = g, code == 401 || code == 403 {
                    rejected[c.id] = c.key
                }
                last = ProviderError(provider: c.id.shortName, underlying: error)
            }
        }
        throw last
    }

    private static func send(wav: Data, forced: String?, timeout: TimeInterval,
                             c: ProviderConfig, model: String) async throws -> WhisperOutcome {
        var base = c.base
        while base.hasSuffix("/") { base.removeLast() }
        guard let url = URL(string: base + "/audio/transcriptions") else { throw GeminiError.badResponse }

        let boundary = "Boundary-\(UUID().uuidString)"
        var body = Data()
        func field(_ name: String, _ value: String) {
            body.append(Data("--\(boundary)\r\nContent-Disposition: form-data; name=\"\(name)\"\r\n\r\n\(value)\r\n".utf8))
        }
        field("model", model)
        field("response_format", "verbose_json")
        field("temperature", "0")
        if let f = forced { field("language", f) }
        // Gợi ý từ vựng (tên riêng, thuật ngữ trong bảng thuật ngữ) để nhận giọng đúng hơn.
        let terms = AppSettings.glossary.split(separator: "\n")
            .compactMap { $0.split(separator: "=").first?.trimmingCharacters(in: .whitespaces) }
            .filter { !$0.isEmpty }.joined(separator: ", ")
        if !terms.isEmpty { field("prompt", String(terms.prefix(200))) }
        body.append(Data("--\(boundary)\r\nContent-Disposition: form-data; name=\"file\"; filename=\"speech.wav\"\r\nContent-Type: audio/wav\r\n\r\n".utf8))
        body.append(wav)
        body.append(Data("\r\n--\(boundary)--\r\n".utf8))

        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.timeoutInterval = timeout
        req.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        req.setValue("Bearer \(c.key)", forHTTPHeaderField: "Authorization")
        req.httpBody = body

        let (data, resp) = try await URLSession.shared.data(for: req)
        guard let http = resp as? HTTPURLResponse else { throw GeminiError.badResponse }
        guard http.statusCode == 200 else {
            let snippet = String((String(data: data, encoding: .utf8) ?? "").prefix(140))
            throw GeminiError.http(http.statusCode, snippet)
        }
        guard let obj = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw GeminiError.badResponse
        }

        let text = (obj["text"] as? String ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        let segments = obj["segments"] as? [[String: Any]] ?? []
        if text.isEmpty || looksLikeNoise(text: text, segments: segments) { return .noSpeech }

        if let f = forced { return .result(WhisperResult(lang: f, text: text)) }
        let l = (obj["language"] as? String ?? "").lowercased()
        if l.hasPrefix("vi") { return .result(WhisperResult(lang: "vi", text: text)) }
        if l.hasPrefix("en") { return .result(WhisperResult(lang: "en", text: text)) }
        return .unsupportedLanguage
    }

    /// Whisper hay "bịa" chữ khi chỉ có tiếng ồn: lọc theo xác suất không-có-tiếng-nói và các câu bịa quen thuộc.
    private static func looksLikeNoise(text: String, segments: [[String: Any]]) -> Bool {
        if !segments.isEmpty {
            let silent = segments.allSatisfy {
                ($0["no_speech_prob"] as? Double ?? 0) > 0.6 && ($0["avg_logprob"] as? Double ?? 0) < -0.7
            }
            if silent { return true }
            if segments.contains(where: { ($0["compression_ratio"] as? Double ?? 0) > 2.4 }) { return true }
        }
        let l = text.lowercased()
        let known = ["đăng ký kênh", "subscribe", "cảm ơn các bạn đã theo dõi", "cảm ơn các bạn đã xem",
                     "hẹn gặp lại các bạn", "thanks for watching", "thank you for watching",
                     "ghiền mì gõ", "la la school", "amara.org"]
        return known.contains { l.contains($0) }
    }

    /// Cắt phần im lặng ở đầu, đổi sang WAV 16 kHz mono. nil nếu gần như không có tiếng.
    static func wav(from samples: [Int16]) -> Data? {
        let window = 320   // 20 ms ở 16 kHz
        var first: Int?
        var i = 0
        while i + window <= samples.count {
            var peak: Int32 = 0
            for j in i..<(i + window) { peak = max(peak, abs(Int32(samples[j]))) }
            if peak > 350 { first = i; break }
            i += window
        }
        guard let first else { return nil }
        let start = max(0, first - 8000)   // giữ lại 0,5 giây trước chỗ bắt đầu nói
        let slice = Array(samples[start...])
        guard slice.count >= 4800 else { return nil }   // ngắn hơn 0,3 giây

        var d = Data()
        let dataSize = UInt32(slice.count * 2)
        func u32(_ v: UInt32) { var x = v.littleEndian; d.append(Data(bytes: &x, count: 4)) }
        func u16(_ v: UInt16) { var x = v.littleEndian; d.append(Data(bytes: &x, count: 2)) }
        d.append(Data("RIFF".utf8)); u32(36 + dataSize); d.append(Data("WAVE".utf8))
        d.append(Data("fmt ".utf8)); u32(16); u16(1); u16(1); u32(16000); u32(32000); u16(2); u16(16)
        d.append(Data("data".utf8)); u32(dataSize)
        slice.withUnsafeBufferPointer { d.append(Data(buffer: $0)) }
        return d
    }
}
