import Foundation

struct GeminiResult {
    let lang: String        // "vi" hoặc "en"
    let text: String        // câu gốc đã chỉnh lỗi nhận giọng
    let translation: String
}

enum GeminiError: LocalizedError {
    case http(Int, String)
    case badResponse

    var errorDescription: String? {
        switch self {
        case .http(let code, let body):
            if code == 429 { return "Hết hạn mức miễn phí tạm thời (429)" }
            if code == 400 || code == 403 { return "Key/model không hợp lệ (\(code)): \(body)" }
            if code == 404 { return "Không tìm thấy model (404): \(body)" }
            return "Lỗi \(code): \(body)"
        case .badResponse:
            return "Phản hồi Gemini không đọc được"
        }
    }
}

enum GeminiClient {
    static func process(candidates: [(lang: String, text: String)],
                        context: [(lang: String, text: String)],
                        key: String,
                        model: String) async throws -> GeminiResult {
        var name = model
        if name.hasPrefix("models/") { name = String(name.dropFirst(7)) }
        guard let url = URL(string:
            "https://generativelanguage.googleapis.com/v1beta/models/\(name):generateContent")
        else { throw GeminiError.badResponse }

        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.timeoutInterval = 15
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.setValue(key, forHTTPHeaderField: "x-goog-api-key")

        let body: [String: Any] = [
            "contents": [["parts": [["text": prompt(candidates, context)]]]],
            "generationConfig": [
                "responseMimeType": "application/json",
                "temperature": 0.2
            ]
        ]
        req.httpBody = try JSONSerialization.data(withJSONObject: body)

        let (data, resp) = try await URLSession.shared.data(for: req)
        guard let http = resp as? HTTPURLResponse else { throw GeminiError.badResponse }
        guard http.statusCode == 200 else {
            let snippet = String((String(data: data, encoding: .utf8) ?? "").prefix(140))
            throw GeminiError.http(http.statusCode, snippet)
        }

        guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              let cands = root["candidates"] as? [[String: Any]],
              let content = cands.first?["content"] as? [String: Any],
              let parts = content["parts"] as? [[String: Any]]
        else { throw GeminiError.badResponse }

        var text = parts
            .filter { ($0["thought"] as? Bool) != true }
            .compactMap { $0["text"] as? String }
            .joined()
        text = text.replacingOccurrences(of: "```json", with: "")
            .replacingOccurrences(of: "```", with: "")
            .trimmingCharacters(in: .whitespacesAndNewlines)

        guard let obj = try JSONSerialization.jsonObject(with: Data(text.utf8)) as? [String: Any],
              let translation = obj["translation"] as? String, !translation.isEmpty
        else { throw GeminiError.badResponse }

        let rawLang = (obj["lang"] as? String)?.lowercased() ?? candidates.first?.lang ?? "en"
        let lang = rawLang.hasPrefix("vi") ? "vi" : "en"
        let clean = (obj["text"] as? String).flatMap { $0.isEmpty ? nil : $0 }
            ?? candidates.first?.text ?? ""
        return GeminiResult(lang: lang, text: clean, translation: translation)
    }

    private static func prompt(_ cands: [(lang: String, text: String)],
                               _ context: [(lang: String, text: String)]) -> String {
        var s = """
        You are a live interpreter between Vietnamese and English speakers in a face-to-face conversation.
        One or two speech recognizers heard the same audio; each assumed a different language. \
        The recognizer that assumed the wrong language usually outputs gibberish or phonetically similar nonsense.
        Tasks: (1) decide which language was really spoken, (2) lightly fix obvious recognition errors using the \
        conversation context, (3) translate into the other language (Vietnamese -> English, English -> Vietnamese) \
        naturally, the way a person would say it.
        Reply ONLY with JSON: {"lang":"vi" or "en","text":"cleaned transcript in the spoken language","translation":"..."}

        """
        if !context.isEmpty {
            s += "\nRecent conversation (oldest first):\n"
            for c in context { s += "- [\(c.lang)] \(c.text)\n" }
        }
        s += "\nRecognizer outputs:\n"
        for c in cands {
            let label = c.lang == "vi" ? "Vietnamese recognizer" : "English recognizer"
            s += "- \(label): \"\(c.text)\"\n"
        }
        return s
    }
}
