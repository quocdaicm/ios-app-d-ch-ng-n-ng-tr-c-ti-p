import SwiftUI

private func markdown(_ s: String) -> AttributedString {
    var t = s.replacingOccurrences(of: "(?m)^\\s*[\\*\\-]\\s+", with: "• ", options: .regularExpression)
    t = t.replacingOccurrences(of: "(?m)^#{1,6}\\s+", with: "", options: .regularExpression)
    let opts = AttributedString.MarkdownParsingOptions(
        interpretedSyntax: .inlineOnlyPreservingWhitespace)
    return (try? AttributedString(markdown: t, options: opts)) ?? AttributedString(t)
}

struct ChatView: View {
    @ObservedObject var chat: ChatStore
    let hasConversation: Bool
    let contextText: () -> String
    var openSettings: () -> Void

    @State private var input = ""
    @State private var attach = true

    private let quick = [
        "Tóm tắt cuộc hội thoại",
        "Giải thích các từ/cụm khó",
        "Gợi ý câu trả lời tiếp theo",
        "Kiểm tra bản dịch có chính xác không"
    ]

    var body: some View {
        VStack(spacing: 0) {
            if hasConversation || !chat.messages.isEmpty { topRow }

            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(spacing: 12) {
                        if chat.messages.isEmpty { emptyState }
                        ForEach(chat.messages) { m in
                            ChatBubble(message: m).id(m.id)
                                .transition(.move(edge: .bottom).combined(with: .opacity))
                        }
                        if chat.sending {
                            HStack {
                                TypingDots()
                                    .padding(.horizontal, 18).padding(.vertical, 12)
                                    .background(.ultraThinMaterial, in: Capsule())
                                    .overlay(Capsule().strokeBorder(.white.opacity(0.15), lineWidth: 1))
                                Spacer()
                            }
                        }
                        Color.clear.frame(height: 1).id("end")
                    }
                    .padding(.horizontal, 16).padding(.top, 8)
                    .animation(.spring(response: 0.4, dampingFraction: 0.85), value: chat.messages.count)
                }
                .scrollIndicators(.hidden)
                .scrollDismissesKeyboard(.interactively)
                .onChange(of: chat.messages.count) { _, _ in scroll(proxy) }
                .onChange(of: chat.sending) { _, _ in scroll(proxy) }
            }

            VStack(spacing: 8) {
                if hasConversation { quickChips }
                inputBar
            }
            .padding(.top, 8)
            .background(
                LinearGradient(colors: [.clear, .black.opacity(0.4)], startPoint: .top, endPoint: .bottom)
                    .ignoresSafeArea(edges: .bottom))
        }
    }

    // MARK: - Pieces

    private var topRow: some View {
        HStack {
            if hasConversation {
                Button { withAnimation(.spring(response: 0.3)) { attach.toggle() } } label: {
                    HStack(spacing: 6) {
                        Image(systemName: attach ? "checkmark.circle.fill" : "circle")
                        Text("Kèm hội thoại đang dịch")
                    }
                    .font(.system(.caption, design: .rounded).weight(.semibold))
                    .foregroundStyle(attach ? Color.white : Color.white.opacity(0.6))
                    .padding(.horizontal, 12).padding(.vertical, 7)
                    .background(.ultraThinMaterial, in: Capsule())
                    .overlay(Capsule().strokeBorder(
                        attach ? Color(r: 130, g: 110, b: 255).opacity(0.8) : Color.white.opacity(0.15), lineWidth: 1))
                }
                .buttonStyle(PressScale())
            }
            Spacer()
            if !chat.messages.isEmpty {
                Button { chat.clear() } label: {
                    Image(systemName: "trash")
                        .font(.system(size: 14, weight: .medium))
                        .foregroundStyle(.white.opacity(0.8))
                        .frame(width: 34, height: 34)
                        .background(.ultraThinMaterial, in: Circle())
                        .overlay(Circle().strokeBorder(.white.opacity(0.15), lineWidth: 1))
                }
                .buttonStyle(PressScale())
            }
        }
        .padding(.horizontal, 20).padding(.top, 2)
    }

    private var emptyState: some View {
        VStack(spacing: 14) {
            ZStack {
                Circle()
                    .fill(LinearGradient(colors: [Color(r: 130, g: 80, b: 255), Color(r: 60, g: 190, b: 255)],
                                         startPoint: .topLeading, endPoint: .bottomTrailing))
                    .frame(width: 84, height: 84)
                    .shadow(color: Color(r: 120, g: 90, b: 255).opacity(0.6), radius: 26, y: 8)
                Image(systemName: "sparkles").font(.system(size: 34, weight: .medium)).foregroundStyle(.white)
            }
            Text("Hỏi AI bất cứ điều gì")
                .font(.system(.title3, design: .rounded).weight(.bold)).foregroundStyle(.white)
            Text(hasConversation
                 ? "Nhờ tóm tắt, giải thích từ khó hoặc gợi ý câu trả lời cho cuộc hội thoại bạn vừa dịch."
                 : "Chat tự do, hoặc dịch một đoạn hội thoại rồi quay lại đây để hỏi về nó.")
                .font(.system(.callout, design: .rounded))
                .foregroundStyle(.white.opacity(0.65))
                .multilineTextAlignment(.center)
            if AppSettings.providers().isEmpty {
                Button(action: openSettings) {
                    Label("Nhập API key", systemImage: "key.fill")
                        .font(.system(.footnote, design: .rounded).weight(.semibold))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 16).padding(.vertical, 9)
                        .background(Capsule().fill(Color(r: 110, g: 90, b: 255)))
                }
                .buttonStyle(PressScale())
            }
        }
        .padding(.horizontal, 32).padding(.top, 48)
    }

    private var quickChips: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(quick, id: \.self) { q in
                    Button { send(q, forceContext: true) } label: {
                        Text(q)
                            .font(.system(.footnote, design: .rounded).weight(.medium))
                            .foregroundStyle(.white)
                            .padding(.horizontal, 14).padding(.vertical, 8)
                            .background(.ultraThinMaterial, in: Capsule())
                            .overlay(Capsule().strokeBorder(.white.opacity(0.18), lineWidth: 1))
                    }
                    .buttonStyle(PressScale())
                    .disabled(chat.sending)
                }
            }
            .padding(.horizontal, 16)
        }
    }

    private var inputBar: some View {
        HStack(alignment: .bottom, spacing: 10) {
            TextField("Nhắn cho AI…", text: $input, prompt: Text("Nhắn cho AI…").foregroundStyle(.white.opacity(0.45)), axis: .vertical)
                .lineLimit(1...5)
                .foregroundStyle(.white)
                .padding(.horizontal, 16).padding(.vertical, 12)
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous)
                    .strokeBorder(.white.opacity(0.18), lineWidth: 1))

            Button { send(input, forceContext: false) } label: {
                Image(systemName: "arrow.up")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundStyle(.white)
                    .frame(width: 46, height: 46)
                    .background(Circle().fill(LinearGradient(
                        colors: [Color(r: 70, g: 130, b: 255), Color(r: 140, g: 80, b: 255)],
                        startPoint: .topLeading, endPoint: .bottomTrailing)))
                    .shadow(color: Color(r: 100, g: 90, b: 255).opacity(0.5), radius: 10, y: 4)
            }
            .buttonStyle(PressScale())
            .disabled(input.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || chat.sending)
            .opacity(input.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || chat.sending ? 0.45 : 1)
        }
        .padding(.horizontal, 16).padding(.bottom, 8)
    }

    // MARK: - Actions

    private func send(_ text: String, forceContext: Bool) {
        let useContext = (forceContext || attach) && hasConversation
        chat.send(text, context: useContext ? contextText() : nil)
        input = ""
    }

    private func scroll(_ proxy: ScrollViewProxy) {
        withAnimation(.easeOut(duration: 0.25)) { proxy.scrollTo("end", anchor: .bottom) }
    }
}

struct ChatBubble: View {
    let message: ChatMessage
    private var isUser: Bool { message.role == "user" }

    var body: some View {
        HStack(alignment: .top, spacing: 8) {
            if isUser { Spacer(minLength: 48) }
            if !isUser {
                Image(systemName: "sparkles")
                    .font(.system(size: 12, weight: .bold))
                    .foregroundStyle(.white)
                    .frame(width: 28, height: 28)
                    .background(Circle().fill(LinearGradient(
                        colors: [Color(r: 130, g: 80, b: 255), Color(r: 60, g: 190, b: 255)],
                        startPoint: .topLeading, endPoint: .bottomTrailing)))
                    .padding(.top, 4)
            }
            Text(markdown(message.text))
                .font(.system(.body, design: .rounded))
                .foregroundStyle(message.isError ? Color.orange : Color.white)
                .textSelection(.enabled)
                .padding(.horizontal, 16).padding(.vertical, 12)
                .background { bubbleShape.fill(isUser ? AnyShapeStyle(LinearGradient(
                    colors: [Color(r: 70, g: 130, b: 255), Color(r: 140, g: 80, b: 255)],
                    startPoint: .topLeading, endPoint: .bottomTrailing)) : AnyShapeStyle(Material.ultraThinMaterial)) }
                .overlay { bubbleShape.strokeBorder(.white.opacity(isUser ? 0.25 : 0.15), lineWidth: 1) }
                .contextMenu {
                    Button("Sao chép", systemImage: "doc.on.doc") { UIPasteboard.general.string = message.text }
                }
            if !isUser { Spacer(minLength: 24) }
        }
    }

    private var bubbleShape: UnevenRoundedRectangle {
        UnevenRoundedRectangle(topLeadingRadius: 22,
                               bottomLeadingRadius: isUser ? 22 : 6,
                               bottomTrailingRadius: isUser ? 6 : 22,
                               topTrailingRadius: 22, style: .continuous)
    }
}
