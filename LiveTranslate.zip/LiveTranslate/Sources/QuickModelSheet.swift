import SwiftUI

/// Đổi nhanh nhà cung cấp AI (đứng đầu thứ tự ưu tiên) và model ngay ở trang chủ.
struct QuickModelSheet: View {
    var openSettings: () -> Void

    @Environment(\.dismiss) private var dismiss
    @State private var order = ProviderSettings.order()
    @State private var tick = 0
    @State private var loading: ProviderID?
    @State private var pickerFor: ProviderID?
    @State private var models: [String] = []
    @State private var message = ""

    private var ready: [ProviderID] { order.filter { ProviderSettings.config($0) != nil } }

    var body: some View {
        NavigationStack {
            List {
                if ready.isEmpty {
                    Section {
                        Text("Chưa có nhà cung cấp AI nào. Vào Cài đặt để nhập API key.")
                            .font(.footnote).foregroundStyle(.white.opacity(0.7))
                            .listRowBackground(Color.clear)
                        Button("Mở Cài đặt", action: openSettings)
                    }
                } else {
                    Section {
                        ForEach(Array(ready.enumerated()), id: \.element) { idx, p in
                            row(p, primary: idx == 0)
                        }
                    } header: {
                        Text("Bấm vào nhà cung cấp để dùng trước")
                    } footer: {
                        Text("Nhà đứng đầu được dùng trước; nếu lỗi, app tự chuyển sang nhà kế tiếp.")
                    }
                    if !message.isEmpty {
                        Section { Text(message).font(.footnote).foregroundStyle(.orange) }
                    }
                    Section {
                        Button { openSettings() } label: {
                            Label("Cài đặt nâng cao", systemImage: "gearshape")
                        }
                    }
                }
            }
            .id(tick)
            .scrollContentBackground(.hidden)
            .background { AuroraBackground(listening: false, animated: false) }
            .navigationTitle("Mô hình AI")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Xong") { dismiss() } } }
        }
        .preferredColorScheme(.dark)
        .sheet(item: $pickerFor) { p in
            ModelPicker(models: models, current: ProviderSettings.model(p)) { m in
                ProviderSettings.setModel(p, m)
                makePrimary(p)
            }
        }
    }

    private func row(_ p: ProviderID, primary: Bool) -> some View {
        HStack(spacing: 12) {
            Button { makePrimary(p) } label: {
                HStack(spacing: 12) {
                    Image(systemName: p.icon)
                        .foregroundStyle(p.color)
                        .frame(width: 26)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(p.shortName).font(.system(.body, design: .rounded).weight(.semibold))
                        Text(ProviderSettings.model(p))
                            .font(.system(.caption, design: .monospaced))
                            .foregroundStyle(.white.opacity(0.6))
                            .lineLimit(1)
                    }
                    Spacer(minLength: 4)
                    if primary { Image(systemName: "checkmark.circle.fill").foregroundStyle(.green) }
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)

            Button { loadModels(p) } label: {
                if loading == p {
                    ProgressView()
                } else {
                    Text("Đổi model")
                        .font(.system(.caption, design: .rounded).weight(.semibold))
                        .padding(.horizontal, 10).padding(.vertical, 6)
                        .background(Color.white.opacity(0.14), in: Capsule())
                }
            }
            .buttonStyle(.plain)
            .disabled(loading != nil)
        }
        .listRowBackground(Color.white.opacity(0.08))
    }

    private func makePrimary(_ p: ProviderID) {
        var o = ProviderSettings.order()
        o.removeAll { $0 == p }
        o.insert(p, at: 0)
        ProviderSettings.saveOrder(o)
        order = o
        tick += 1
    }

    private func loadModels(_ p: ProviderID) {
        guard let cfg = ProviderSettings.config(p) else { return }
        loading = p
        message = ""
        Task {
            do {
                models = try await LLM.listModels(cfg)
                pickerFor = p
            } catch {
                message = "Không dò được danh sách model của \(p.shortName): \(error.localizedDescription). Có thể nhập tên model trong Cài đặt nâng cao."
            }
            loading = nil
        }
    }
}
