import SwiftUI

@main
struct LiveTranslateApp: App {
    var body: some Scene {
        WindowGroup { ContentView() }
    }
}
