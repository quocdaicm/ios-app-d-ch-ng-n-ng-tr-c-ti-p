import AVFoundation

/// Đọc to bản dịch. Khi đang đọc, micro tạm bỏ qua âm thanh để không nghe lại chính giọng đọc.
final class Speaker: NSObject, AVSpeechSynthesizerDelegate {
    static let shared = Speaker()
    static var isSpeaking = false

    private let synth = AVSpeechSynthesizer()

    override init() {
        super.init()
        synth.delegate = self
    }

    /// `lang` là ngôn ngữ của đoạn văn cần đọc ("vi" hoặc "en").
    func speak(_ text: String, lang: String) {
        let t = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !t.isEmpty else { return }
        if synth.isSpeaking { synth.stopSpeaking(at: .immediate) }
        let u = AVSpeechUtterance(string: t)
        u.voice = AVSpeechSynthesisVoice(language: lang == "vi" ? "vi-VN" : "en-US")
        Speaker.isSpeaking = true
        synth.speak(u)
        // Phòng khi không nhận được báo đọc xong: tự mở lại micro, không để bị tắt mãi.
        let limit = min(60, 6 + Double(t.count) * 0.15)
        DispatchQueue.main.asyncAfter(deadline: .now() + limit) { [weak self] in
            guard let self, !self.synth.isSpeaking else { return }
            Speaker.isSpeaking = false
        }
    }

    func stop() {
        synth.stopSpeaking(at: .immediate)
    }

    private func finished() {
        // Chờ thêm một chút cho tiếng vọng tắt hẳn rồi mới nghe lại.
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { [weak self] in
            guard let self, !self.synth.isSpeaking else { return }
            Speaker.isSpeaking = false
        }
    }

    func speechSynthesizer(_ s: AVSpeechSynthesizer, didFinish u: AVSpeechUtterance) { finished() }
    func speechSynthesizer(_ s: AVSpeechSynthesizer, didCancel u: AVSpeechUtterance) { finished() }
}
