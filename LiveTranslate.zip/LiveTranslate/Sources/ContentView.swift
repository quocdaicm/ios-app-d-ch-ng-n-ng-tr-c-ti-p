import SwiftUI
import Translation

enum Mode: String, CaseIterable, Identifiable {
    case auto = "Tự động"
    case viOnly = "🇻🇳 Chỉ Việt"
    case enOnly = "🇬🇧 Chỉ Anh"
    var id: String { rawValue }
    var locales: [Locale] {
        switch self {
        case .auto: return [Locale(identifier: "vi-VN"), Locale(identifier: "en-US")]
        case .viOnly: return [Locale(identifier: "vi-VN")]
        case .enOnly: return [Locale(identifier: "en-US")]
        }
    }
}

struct ContentView: View {
    @StateObject private var listener = ConversationListener()
    @StateObject private var store = ConversationStore()
    @State private var mode: Mode = .auto
    @State private var cfgVi: TranslationSession.Configuration?
    @State private var cfgEn: TranslationSession.Configuration?
    @State private var liveDebounce: Task<Void, Never>?
    @State private var showSettings = false
    @State private var geminiOn = AppSettings.gemini() != nil

    var body: some View {
        ZStack {
            AuroraBackground(listening: listener.isRunning)
            VStack(spacing: 14) {
                header
                ModePicker(mode: $mode, disabled: listener.isRunning)
                    .padding(.horizontal, 20)
                conversation
                bottomBar
            }
        }
        .preferredColorScheme(.dark)
        .sensoryFeedback(.impact(weight: .light), trigger: store.items.count)
        .onAppear {
            cfgVi = .init(source: Locale.Language(identifier: "vi"), target: Locale.Language(identifier: "en"))
            cfgEn = .init(source: Locale.Language(identifier: "en"), target: Locale.Language(identifier: "vi"))
            listener.onUtterance = { cands in
                store.gemini = AppSettings.gemini()
                store.add(candidates: cands)
            }
        }
        .onChange(of: store.tick) { _, _ in
            cfgVi?.invalidate()
            cfgEn?.invalidate()
        }
        .onChange(of: listener.liveText) { _, new in
            liveDebounce?.cancel()
            if new.isEmpty { store.setLive(text: "", lang: listener.liveLang); return }
            store.liveOriginal = new
            store.liveLang = listener.liveLang
            let lang = listener.liveLang
            liveDebounce = Task {
                try? await Task.sleep(nanoseconds: 600_000_000)
                if !Task.isCancelled { store.setLive(text: new, lang: lang) }
            }
        }
        .onChange(of: listener.isRunning) { _, running in
            UIApplication.shared.isIdleTimerDisabled = running
        }
        .sheet(isPresented: $showSettings, onDismiss: { geminiOn = AppSettings.gemini() != nil }) {
            SettingsView()
        }
        .translationTask(cfgVi) { session in await store.drain(session, lang: "vi") }
        .translationTask(cfgEn) { session in await store.drain(session, lang: "en") }
    }

    // MARK: - Sections

    private var header: some View {
        HStack(alignment: .center) {
            VStack(alignment: .leading, spacing: 8) {
                Text("Dịch Hội Thoại")
                    .font(.system(size: 28, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)
                StatusPill(running: listener.isRunning, gemini: geminiOn)
            }
            Spacer()
            Button { showSettings = true } label: { GlassIcon(icon: "gearshape.fill") }
                .buttonStyle(PressScale())
        }
        .padding(.horizontal, 20)
        .padding(.top, 6)
    }

    private var conversation: some View {
        ScrollViewReader { proxy in
            ScrollView {
                LazyVStack(spacing: 12) {
                    if store.items.isEmpty && store.liveOriginal.isEmpty {
                        EmptyState().transition(.opacity)
                    }
                    ForEach(store.items) { u in
                        BubbleView(lang: u.lang, original: u.original, translated: u.translated, live: false)
                            .transition(.asymmetric(
                                insertion: .move(edge: .bottom).combined(with: .opacity).combined(with: .scale(scale: 0.96)),
                                removal: .opacity))
                    }
                    if !store.liveOriginal.isEmpty {
                        BubbleView(lang: store.liveLang, original: store.liveOriginal,
                                   translated: store.liveTranslated.isEmpty ? nil : store.liveTranslated,
                                   live: true)
                            .transition(.opacity)
                    }
                    Color.clear.frame(height: 1).id("bottom")
                }
                .padding(.horizontal, 16)
                .padding(.top, 4)
                .animation(.spring(response: 0.45, dampingFraction: 0.82), value: store.items.count)
                .animation(.easeOut(duration: 0.2), value: store.liveOriginal.isEmpty)
            }
            .scrollIndicators(.hidden)
            .onChange(of: store.items.count) { _, _ in scroll(proxy) }
            .onChange(of: store.liveOriginal) { _, _ in scroll(proxy) }
            .onChange(of: store.liveTranslated) { _, _ in scroll(proxy) }
        }
    }

    private var bottomBar: some View {
        VStack(spacing: 10) {
            if !store.notice.isEmpty {
                HStack(spacing: 6) {
                    Image(systemName: "exclamationmark.triangle.fill")
                    Text(store.notice).lineLimit(2)
                }
                .font(.system(.caption, design: .rounded))
                .foregroundStyle(Color.orange)
                .padding(.horizontal, 12).padding(.vertical, 7)
                .background(.ultraThinMaterial, in: Capsule())
                .padding(.horizontal, 20)
            }
            if !listener.status.isEmpty {
                Text(listener.status)
                    .font(.system(.caption, design: .rounded))
                    .foregroundStyle(.white.opacity(0.7))
            }
            HStack {
                Button { store.clear() } label: { GlassIcon(icon: "trash") }
                    .buttonStyle(PressScale())
                    .disabled(store.items.isEmpty)
                Spacer()
                MicOrb(running: listener.isRunning, meter: listener.meter, action: toggle)
                Spacer()
                ShareLink(item: transcript) { GlassIcon(icon: "square.and.arrow.up") }
                    .disabled(store.items.isEmpty)
            }
            .padding(.horizontal, 30)
            Text(listener.isRunning ? "Chạm để dừng" : "Chạm để bắt đầu")
                .font(.system(.caption, design: .rounded).weight(.medium))
                .foregroundStyle(.white.opacity(0.55))
        }
        .padding(.top, 12)
        .padding(.bottom, 6)
        .background(
            LinearGradient(colors: [.clear, .black.opacity(0.45)], startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea(edges: .bottom)
        )
    }

    // MARK: - Helpers

    private var transcript: String {
        store.items.map { u in
            let flag = u.lang == "vi" ? "🇻🇳" : "🇬🇧"
            return "\(flag) \(u.original)\n→ \(u.translated ?? "")"
        }.joined(separator: "\n\n")
    }

    private func scroll(_ proxy: ScrollViewProxy) {
        withAnimation(.easeOut(duration: 0.25)) { proxy.scrollTo("bottom", anchor: .bottom) }
    }

    private func toggle() {
        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
        if listener.isRunning {
            listener.stop()
        } else {
            listener.authorize { ok in
                if ok {
                    listener.locales = mode.locales
                    listener.start()
                } else {
                    listener.status = "Hãy cấp quyền micro và nhận giọng nói trong Cài đặt."
                }
            }
        }
    }
}
