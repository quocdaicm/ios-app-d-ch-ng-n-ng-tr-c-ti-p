import SwiftUI
import Translation

enum Mode: String, CaseIterable, Identifiable {
    case auto = "Tự động"
    case viOnly = "🇻🇳 Chỉ Việt"
    case enOnly = "🇬🇧 Chỉ Anh"
    var id: String { rawValue }
    var locales: [Locale] {
        switch self {
        case .auto: return [Locale(identifier: "vi-VN"), Locale(identifier: "en-US")]
        case .viOnly: return [Locale(identifier: "vi-VN")]
        case .enOnly: return [Locale(identifier: "en-US")]
        }
    }
}

enum AppTab: String, CaseIterable {
    case translate = "🌐 Dịch"
    case chat = "✦ Chat AI"
}

struct ContentView: View {
    @StateObject private var listener = ConversationListener()
    @StateObject private var store = ConversationStore()
    @StateObject private var chat = ChatStore()
    @State private var tab: AppTab = .translate
    @State private var mode: Mode = .auto
    @State private var cfgVi: TranslationSession.Configuration?
    @State private var cfgEn: TranslationSession.Configuration?
    @State private var liveDebounce: Task<Void, Never>?
    @Environment(\.scenePhase) private var scenePhase
    @State private var showSettings = false
    @State private var showModels = false
    @State private var aiLabel: String? = AppSettings.label()

    var body: some View {
        VStack(spacing: 12) {
                header
                GlassSegmented(items: AppTab.allCases, title: { $0.rawValue }, selection: $tab)
                    .padding(.horizontal, 20)
                if tab == .translate {
                    GlassSegmented(items: Mode.allCases, title: { $0.rawValue },
                                   selection: $mode, disabled: listener.isRunning)
                        .padding(.horizontal, 20)
                    conversation
                    bottomBar
                } else {
                    ChatView(chat: chat,
                             hasConversation: !store.items.isEmpty,
                             hasProvider: aiLabel != nil,
                             contextText: { chatContext() },
                             openSettings: { showSettings = true })
                }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background { AuroraBackground(listening: listener.isRunning,
                                      // Chỉ cho nền chuyển động khi đang nghe và app đang mở; lúc rảnh để nền tĩnh cho nhẹ máy
                                      animated: tab == .translate && listener.isRunning && scenePhase == .active) }
        .preferredColorScheme(.dark)
        .sensoryFeedback(.impact(weight: .light), trigger: store.items.count)
        .onAppear {
            cfgVi = .init(source: Locale.Language(identifier: "vi"), target: Locale.Language(identifier: "en"))
            cfgEn = .init(source: Locale.Language(identifier: "en"), target: Locale.Language(identifier: "vi"))
            listener.onUtterance = { cands, audio in
                store.providers = AppSettings.providers()
                store.add(candidates: cands, audio: audio, forced: listener.forcedLang)
            }
        }
        .onChange(of: store.tick) { _, _ in
            guard store.hasAppleWork else { return }
            cfgVi?.invalidate()
            cfgEn?.invalidate()
        }
        .onChange(of: listener.liveText) { _, new in
            if new.isEmpty {
                liveDebounce?.cancel()
                liveDebounce = nil
                store.setLive(text: "", lang: listener.liveLang)
                return
            }
            // Hiện chữ gốc ngay lập tức khi đang nói
            store.liveOriginal = new
            store.liveLang = listener.liveLang
            // Dịch liên tục: cứ ~0.7 giây cập nhật bản dịch một lần (không chờ im lặng)
            if liveDebounce == nil {
                liveDebounce = Task {
                    try? await Task.sleep(nanoseconds: 700_000_000)
                    liveDebounce = nil
                    if !Task.isCancelled {
                        store.setLive(text: listener.liveText, lang: listener.liveLang)
                    }
                }
            }
        }
        .onChange(of: store.items.last?.lang) { _, l in
            if let l { listener.preferLang(l) }
        }
        .onChange(of: tab) { _, new in
            // Sang tab Chat AI thì tắt mic: tránh nhận giọng + dịch chạy ngầm làm app đứng khi gõ
            if new == .chat, listener.isRunning { listener.stop() }
        }
        .onChange(of: listener.isRunning) { _, running in
            UIApplication.shared.isIdleTimerDisabled = running
        }
        .sheet(isPresented: $showModels, onDismiss: { aiLabel = AppSettings.label() }) {
            QuickModelSheet(openSettings: {
                showModels = false
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { showSettings = true }
            })
            .presentationDetents([.medium, .large])
        }
        .sheet(isPresented: $showSettings, onDismiss: { aiLabel = AppSettings.label() }) {
            SettingsView()
        }
        .translationTask(cfgVi) { session in await store.drain(session, lang: "vi") }
        .translationTask(cfgEn) { session in await store.drain(session, lang: "en") }
    }

    // MARK: - Sections

    private var header: some View {
        HStack(alignment: .center) {
            VStack(alignment: .leading, spacing: 8) {
                Text("Dịch Hội Thoại")
                    .font(.system(size: 28, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)
                Button { showModels = true } label: {
                    StatusPill(running: listener.isRunning, ai: aiLabel)
                }
                .buttonStyle(.plain)
            }
            Spacer()
            Button { showSettings = true } label: { GlassIcon(icon: "gearshape.fill") }
                .buttonStyle(PressScale())
        }
        .padding(.horizontal, 20)
        .padding(.top, 6)
    }

    private var conversation: some View {
        ScrollViewReader { proxy in
            ScrollView {
                LazyVStack(spacing: 12) {
                    if store.items.isEmpty && store.liveOriginal.isEmpty {
                        EmptyState().transition(.opacity)
                    }
                    ForEach(store.items) { u in
                        BubbleView(lang: u.lang, original: u.original, translated: u.translated, live: false,
                                   onSpeak: { Speaker.shared.speak(u.translated ?? "", lang: u.lang == "vi" ? "en" : "vi") })
                            .transition(.asymmetric(
                                insertion: .move(edge: .bottom).combined(with: .opacity).combined(with: .scale(scale: 0.96)),
                                removal: .opacity))
                    }
                    if !store.liveOriginal.isEmpty {
                        BubbleView(lang: store.liveLang, original: store.liveOriginal,
                                   translated: store.liveTranslated.isEmpty ? nil : store.liveTranslated,
                                   live: true)
                            .transition(.opacity)
                    }
                    Color.clear.frame(height: 1).id("bottom")
                }
                .padding(.horizontal, 16)
                .padding(.top, 4)
                .animation(.spring(response: 0.45, dampingFraction: 0.82), value: store.items.count)
                .animation(.easeOut(duration: 0.2), value: store.liveOriginal.isEmpty)
            }
            .scrollIndicators(.hidden)
            .onChange(of: store.items.count) { _, _ in scroll(proxy) }
            .onChange(of: store.liveOriginal) { _, _ in scroll(proxy) }
            .onChange(of: store.liveTranslated) { _, _ in scroll(proxy) }
        }
    }

    private var bottomBar: some View {
        VStack(spacing: 10) {
            if !store.notice.isEmpty {
                HStack(spacing: 6) {
                    Image(systemName: "exclamationmark.triangle.fill")
                    Text(store.notice).lineLimit(2)
                }
                .font(.system(.caption, design: .rounded))
                .foregroundStyle(Color.orange)
                .padding(.horizontal, 12).padding(.vertical, 7)
                .background(.ultraThinMaterial, in: Capsule())
                .padding(.horizontal, 20)
            }
            if !store.items.isEmpty && aiLabel != nil {
                Button { withAnimation(.easeInOut(duration: 0.25)) { tab = .chat } } label: {
                    HStack(spacing: 6) {
                        Image(systemName: "sparkles")
                        Text("Hỏi AI về hội thoại")
                    }
                    .font(.system(.footnote, design: .rounded).weight(.semibold))
                    .foregroundStyle(.white)
                    .padding(.horizontal, 14).padding(.vertical, 8)
                    .background(.ultraThinMaterial, in: Capsule())
                    .overlay(Capsule().strokeBorder(Color(r: 130, g: 110, b: 255).opacity(0.7), lineWidth: 1))
                }
                .buttonStyle(PressScale())
            }
            if !listener.status.isEmpty {
                Text(listener.status)
                    .font(.system(.caption, design: .rounded))
                    .foregroundStyle(.white.opacity(0.7))
            }
            HStack {
                Button { store.clear() } label: { GlassIcon(icon: "trash") }
                    .buttonStyle(PressScale())
                    .disabled(store.items.isEmpty)
                Spacer()
                MicOrb(running: listener.isRunning, meter: listener.meter, action: toggle)
                Spacer()
                ShareLink(item: transcript) { GlassIcon(icon: "square.and.arrow.up") }
                    .disabled(store.items.isEmpty)
            }
            .padding(.horizontal, 30)
            Text(listener.isRunning ? "Chạm để dừng" : "Chạm để bắt đầu")
                .font(.system(.caption, design: .rounded).weight(.medium))
                .foregroundStyle(.white.opacity(0.55))
        }
        .padding(.top, 12)
        .padding(.bottom, 6)
        .background(
            LinearGradient(colors: [.clear, .black.opacity(0.45)], startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea(edges: .bottom)
        )
    }

    // MARK: - Helpers

    private var transcript: String {
        store.items.map { u in
            let flag = u.lang == "vi" ? "🇻🇳" : "🇬🇧"
            return "\(flag) \(u.original)\n→ \(u.translated ?? "")"
        }.joined(separator: "\n\n")
    }

    private func chatContext() -> String {
        store.items.suffix(30).map { u in
            let who = u.lang == "vi" ? "Việt" : "Anh"
            return "[\(who)] \(u.original) → \(u.translated ?? "…")"
        }.joined(separator: "\n")
    }

    private func scroll(_ proxy: ScrollViewProxy) {
        withAnimation(.easeOut(duration: 0.25)) { proxy.scrollTo("bottom", anchor: .bottom) }
    }

    private func toggle() {
        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
        if listener.isRunning {
            listener.stop()
        } else {
            listener.authorize { ok in
                if ok {
                    listener.locales = mode.locales
                    listener.fastMode = Whisper.provider() != nil
                    listener.start()
                } else {
                    listener.status = "Hãy cấp quyền micro và nhận giọng nói trong Cài đặt."
                }
            }
        }
    }
}
