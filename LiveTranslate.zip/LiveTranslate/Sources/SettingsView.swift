import SwiftUI

struct SettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var order = ProviderSettings.order()
    @State private var tick = 0
    @State private var whisperOn = AppSettings.whisperEnabled
    @State private var whisperModel = AppSettings.whisperModel
    @State private var tone = AppSettings.tone
    @State private var addressing = AppSettings.addressing
    @State private var situation = AppSettings.situation
    @State private var glossary = AppSettings.glossary
    @State private var autoSpeak = AppSettings.autoSpeak

    var body: some View {
        NavigationStack {
            List {
                Section {
                    Text("App thử lần lượt các nhà cung cấp theo thứ tự bên dưới. Nhà nào lỗi hoặc quá tải thì tự chuyển sang nhà kế tiếp; hết cả thì dùng dịch offline của Apple. Bấm Sửa để kéo đổi thứ tự ưu tiên.")
                        .font(.footnote)
                        .foregroundStyle(.white.opacity(0.7))
                        .listRowBackground(Color.clear)
                }
                Section {
                    Picker("Giọng văn", selection: $tone) {
                        Text("Tự nhiên").tag("natural")
                        Text("Lịch sự").tag("formal")
                        Text("Thân mật").tag("casual")
                    }
                    .pickerStyle(.segmented)
                    TextField("Xưng hô (vd. tôi xưng em, gọi người kia là anh)", text: $addressing, axis: .vertical)
                        .lineLimit(1...3)
                    TextField("Bối cảnh (vd. đi du lịch, hỏi đường)", text: $situation, axis: .vertical)
                        .lineLimit(1...3)
                    TextField("Từ riêng, mỗi dòng một mục (vd. Minh = giữ nguyên)", text: $glossary, axis: .vertical)
                        .lineLimit(3...8)
                        .autocorrectionDisabled()
                    Toggle("Tự đọc to bản dịch", isOn: $autoSpeak).tint(Color(r: 110, g: 90, b: 255))
                } header: {
                    Text("Dịch thuật")
                } footer: {
                    Text("AI dùng các thiết lập này cho mọi câu dịch và cả khi chat. Điền càng rõ, bản dịch càng đúng ý. Khi đang đọc to, micro tạm dừng nghe để không nghe lại chính giọng đọc.")
                }
                .listRowBackground(Color.white.opacity(0.08))
                Section {
                    Toggle("Nhận giọng bằng Whisper", isOn: $whisperOn).tint(Color(r: 110, g: 90, b: 255))
                    TextField("Model (để trống = mặc định)", text: $whisperModel)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                } header: {
                    Text("Nhận giọng nói")
                } footer: {
                    Text("Chính xác hơn nhận giọng của iPhone. Cần bật Groq hoặc OpenAI và nhập key. Âm thanh từng câu được gửi lên nhà cung cấp đó để chuyển thành chữ. Thiếu key hoặc bị lỗi thì tự dùng nhận giọng của iPhone.")
                }
                .listRowBackground(Color.white.opacity(0.08))
                Section {
                    ForEach(order) { p in
                        NavigationLink { ProviderDetail(p) } label: { ProviderRow(provider: p, tick: tick) }
                    }
                    .onMove { from, to in
                        order.move(fromOffsets: from, toOffset: to)
                        ProviderSettings.saveOrder(order)
                    }
                    .listRowBackground(Color.white.opacity(0.08))
                } header: {
                    Text("Nhà cung cấp AI")
                } footer: {
                    Text("Key chỉ lưu trong Keychain trên iPhone này. Mỗi câu nói gửi chữ lên nhà cung cấp đang dùng; khi bật Whisper, âm thanh câu đó cũng được gửi lên Groq/OpenAI.")
                }
            }
            .scrollContentBackground(.hidden)
            .background { AuroraBackground(listening: false) }
            .navigationTitle("Cài đặt")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { EditButton() }
                ToolbarItem(placement: .topBarTrailing) { Button("Xong") { dismiss() } }
            }
            .onAppear { tick += 1 }
            .onChange(of: whisperOn) { _, v in AppSettings.whisperEnabled = v }
            .onChange(of: whisperModel) { _, v in AppSettings.whisperModel = v }
            .onChange(of: tone) { _, v in AppSettings.tone = v }
            .onChange(of: addressing) { _, v in AppSettings.addressing = v }
            .onChange(of: situation) { _, v in AppSettings.situation = v }
            .onChange(of: glossary) { _, v in AppSettings.glossary = v }
            .onChange(of: autoSpeak) { _, v in AppSettings.autoSpeak = v }
        }
        .preferredColorScheme(.dark)
        .presentationDragIndicator(.visible)
    }
}

struct ProviderRow: View {
    let provider: ProviderID
    let tick: Int

    var body: some View {
        let active = ProviderSettings.config(provider) != nil
        let hasKey = !ProviderSettings.key(provider).isEmpty || provider == .custom
        HStack(spacing: 12) {
            Image(systemName: provider.icon)
                .font(.system(size: 15, weight: .bold))
                .foregroundStyle(.white)
                .frame(width: 34, height: 34)
                .background(Circle().fill(provider.color.gradient))
            VStack(alignment: .leading, spacing: 2) {
                Text(provider.name).font(.system(.body, design: .rounded).weight(.medium))
                Text(active ? "Đang dùng • \(ProviderSettings.model(provider))"
                     : (hasKey ? "Đã tắt" : "Chưa nhập key"))
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.55))
                    .lineLimit(1)
            }
            Spacer()
            Circle().fill(active ? Color.green : Color.white.opacity(0.2)).frame(width: 9, height: 9)
        }
        .padding(.vertical, 2)
    }
}

struct ProviderDetail: View {
    let p: ProviderID
    @State private var key: String
    @State private var enabled: Bool
    @State private var model: String
    @State private var base: String
    @State private var testResult = ""
    @State private var testing = false
    @State private var models: [String] = []
    @State private var loadingModels = false
    @State private var probing = false
    @State private var showPicker = false
    @State private var modelMsg = ""

    init(_ p: ProviderID) {
        self.p = p
        _key = State(initialValue: ProviderSettings.key(p))
        _enabled = State(initialValue: ProviderSettings.enabled(p))
        _model = State(initialValue: ProviderSettings.model(p))
        _base = State(initialValue: ProviderSettings.base(p))
    }

    var body: some View {
        Form {
            Section {
                Toggle("Bật nhà này", isOn: $enabled).tint(Color(r: 110, g: 90, b: 255))
            } footer: {
                Text(p.note)
            }

            Section("API key") {
                SecureField(p == .custom ? "API key (có thể để trống)" : "Dán API key", text: $key)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                Button { if let s = UIPasteboard.general.string { key = s } } label: {
                    Label("Dán từ clipboard", systemImage: "doc.on.clipboard")
                }
                if let url = p.keyURL {
                    Link(destination: url) { Label("Lấy API key", systemImage: "arrow.up.right.square") }
                }
            }

            Section {
                if p == .custom {
                    TextField("Base URL (vd. https://…/v1)", text: $base)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .keyboardType(.URL)
                }
                TextField("Model", text: $model)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                Button { fetchModels() } label: {
                    Label(loadingModels ? "Đang dò…" : "Dò danh sách model", systemImage: "list.bullet.rectangle")
                }
                .disabled(loadingModels || probing || (key.isEmpty && p != .custom))
                Button { autoPick() } label: {
                    Label(probing ? "Đang thử từng model…" : "Tự chọn model dùng được", systemImage: "wand.and.stars")
                }
                .disabled(loadingModels || probing || (key.isEmpty && p != .custom))
                if !modelMsg.isEmpty { Text(modelMsg).font(.footnote) }
            } header: {
                Text("Model")
            } footer: {
                Text("Bấm \"Dò danh sách model\" để xem các model key này dùng được rồi bấm chọn, hoặc để app tự thử và chọn một model chạy được.")
            }

            Section {
                Button { test() } label: {
                    Label(testing ? "Đang thử…" : "Thử kết nối", systemImage: "bolt.horizontal.circle")
                }
                .disabled(testing || (key.isEmpty && p != .custom))
                if !testResult.isEmpty { Text(testResult).font(.footnote) }
            }
        }
        .scrollContentBackground(.hidden)
        .background { AuroraBackground(listening: false) }
        .navigationTitle(p.shortName)
        .navigationBarTitleDisplayMode(.inline)
        .onChange(of: key) { _, v in ProviderSettings.setKey(p, v) }
        .onChange(of: enabled) { _, v in ProviderSettings.setEnabled(p, v) }
        .onChange(of: model) { _, v in ProviderSettings.setModel(p, v) }
        .onChange(of: base) { _, v in ProviderSettings.setBase(p, v) }
        .sheet(isPresented: $showPicker) {
            ModelPicker(models: models, current: model) { model = $0 }
        }
    }

    private func config(model m: String) -> ProviderConfig {
        let b = base.trimmingCharacters(in: .whitespacesAndNewlines)
        return ProviderConfig(id: p,
                              key: key.trimmingCharacters(in: .whitespacesAndNewlines),
                              model: m,
                              base: p == .custom ? b : p.defaultBase)
    }

    private func fetchModels() {
        loadingModels = true
        modelMsg = ""
        Task {
            do {
                models = try await LLM.listModels(config(model: model))
                showPicker = true
            } catch {
                modelMsg = "❌ Không dò được: \(error.localizedDescription)"
            }
            loadingModels = false
        }
    }

    /// Lấy danh sách, rồi thử lần lượt (tối đa 8 model, ưu tiên model nhanh) và chọn cái đầu tiên chạy được.
    private func autoPick() {
        probing = true
        modelMsg = ""
        Task {
            do {
                let all = try await LLM.listModels(config(model: model))
                models = all
                let fast = ["flash", "mini", "haiku", "small", "instant", "lite", "8b", "sonnet"]
                var order: [String] = []
                for m in [model, p.defaultModel] where all.contains(m) && !order.contains(m) { order.append(m) }
                order += all.filter { id in fast.contains { id.lowercased().contains($0) } && !order.contains(id) }
                order += all.filter { !order.contains($0) }

                var picked: String?
                for m in order.prefix(8) {
                    modelMsg = "Đang thử: \(m)"
                    if (try? await LLM.complete(
                        config(model: m), system: "Reply with only the translation.",
                        messages: [(role: "user", text: "Translate to Vietnamese: hello")],
                        json: false, temperature: nil, timeout: 12)) != nil {
                        picked = m
                        break
                    }
                }
                if let picked {
                    model = picked
                    modelMsg = "✅ Đã chọn: \(picked)"
                } else {
                    modelMsg = "❌ Thử 8 model đều lỗi. Bấm \"Dò danh sách model\" để chọn thủ công."
                }
            } catch {
                modelMsg = "❌ Không dò được: \(error.localizedDescription)"
            }
            probing = false
        }
    }

    private func test() {
        testing = true
        testResult = ""
        let m = model.trimmingCharacters(in: .whitespacesAndNewlines)
        let b = base.trimmingCharacters(in: .whitespacesAndNewlines)
        let cfg = ProviderConfig(id: p,
                                 key: key.trimmingCharacters(in: .whitespacesAndNewlines),
                                 model: m.isEmpty ? p.defaultModel : m,
                                 base: p == .custom ? b : p.defaultBase)
        Task {
            do {
                let r = try await LLM.complete(
                    cfg, system: "You are a translator. Reply with only the translation.",
                    messages: [(role: "user", text: "Translate to Vietnamese: hello, how are you today?")],
                    json: false, temperature: nil, timeout: 20)
                testResult = "✅ OK: \(r)"
            } catch {
                testResult = "❌ \(error.localizedDescription)"
            }
            testing = false
        }
    }
}

struct ModelPicker: View {
    let models: [String]
    let current: String
    let onPick: (String) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var search = ""

    private var shown: [String] {
        let q = search.trimmingCharacters(in: .whitespaces).lowercased()
        return q.isEmpty ? models : models.filter { $0.lowercased().contains(q) }
    }

    var body: some View {
        NavigationStack {
            List(shown, id: \.self) { m in
                Button {
                    onPick(m)
                    dismiss()
                } label: {
                    HStack {
                        Text(m).font(.system(.callout, design: .monospaced))
                        Spacer()
                        if m == current { Image(systemName: "checkmark").foregroundStyle(.green) }
                    }
                }
                .listRowBackground(Color.white.opacity(0.08))
            }
            .scrollContentBackground(.hidden)
            .background { AuroraBackground(listening: false) }
            .searchable(text: $search, prompt: "Tìm model")
            .navigationTitle("Chọn model (\(models.count))")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Đóng") { dismiss() } } }
        }
        .preferredColorScheme(.dark)
    }
}
