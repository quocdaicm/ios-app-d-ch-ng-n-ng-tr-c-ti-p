import SwiftUI

struct SettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var order = ProviderSettings.order()
    @State private var tick = 0

    var body: some View {
        NavigationStack {
            List {
                Section {
                    Text("App thử lần lượt các nhà cung cấp theo thứ tự bên dưới. Nhà nào lỗi hoặc quá tải thì tự chuyển sang nhà kế tiếp; hết cả thì dùng dịch offline của Apple. Bấm Sửa để kéo đổi thứ tự ưu tiên.")
                        .font(.footnote)
                        .foregroundStyle(.white.opacity(0.7))
                        .listRowBackground(Color.clear)
                }
                Section {
                    ForEach(order) { p in
                        NavigationLink { ProviderDetail(p) } label: { ProviderRow(provider: p, tick: tick) }
                    }
                    .onMove { from, to in
                        order.move(fromOffsets: from, toOffset: to)
                        ProviderSettings.saveOrder(order)
                    }
                    .listRowBackground(Color.white.opacity(0.08))
                } header: {
                    Text("Nhà cung cấp AI")
                } footer: {
                    Text("Key chỉ lưu trong Keychain trên iPhone này. Mỗi câu nói chỉ gửi chữ (không gửi âm thanh) lên nhà cung cấp đang dùng.")
                }
            }
            .scrollContentBackground(.hidden)
            .background { AuroraBackground(listening: false) }
            .navigationTitle("Cài đặt")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { EditButton() }
                ToolbarItem(placement: .topBarTrailing) { Button("Xong") { dismiss() } }
            }
            .onAppear { tick += 1 }
        }
        .preferredColorScheme(.dark)
        .presentationDragIndicator(.visible)
    }
}

struct ProviderRow: View {
    let provider: ProviderID
    let tick: Int

    var body: some View {
        let active = ProviderSettings.config(provider) != nil
        let hasKey = !ProviderSettings.key(provider).isEmpty || provider == .custom
        HStack(spacing: 12) {
            Image(systemName: provider.icon)
                .font(.system(size: 15, weight: .bold))
                .foregroundStyle(.white)
                .frame(width: 34, height: 34)
                .background(Circle().fill(provider.color.gradient))
            VStack(alignment: .leading, spacing: 2) {
                Text(provider.name).font(.system(.body, design: .rounded).weight(.medium))
                Text(active ? "Đang dùng • \(ProviderSettings.model(provider))"
                     : (hasKey ? "Đã tắt" : "Chưa nhập key"))
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.55))
                    .lineLimit(1)
            }
            Spacer()
            Circle().fill(active ? Color.green : Color.white.opacity(0.2)).frame(width: 9, height: 9)
        }
        .padding(.vertical, 2)
    }
}

struct ProviderDetail: View {
    let p: ProviderID
    @State private var key: String
    @State private var enabled: Bool
    @State private var model: String
    @State private var base: String
    @State private var testResult = ""
    @State private var testing = false

    init(_ p: ProviderID) {
        self.p = p
        _key = State(initialValue: ProviderSettings.key(p))
        _enabled = State(initialValue: ProviderSettings.enabled(p))
        _model = State(initialValue: ProviderSettings.model(p))
        _base = State(initialValue: ProviderSettings.base(p))
    }

    var body: some View {
        Form {
            Section {
                Toggle("Bật nhà này", isOn: $enabled).tint(Color(r: 110, g: 90, b: 255))
            } footer: {
                Text(p.note)
            }

            Section("API key") {
                SecureField(p == .custom ? "API key (có thể để trống)" : "Dán API key", text: $key)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                Button { if let s = UIPasteboard.general.string { key = s } } label: {
                    Label("Dán từ clipboard", systemImage: "doc.on.clipboard")
                }
                if let url = p.keyURL {
                    Link(destination: url) { Label("Lấy API key", systemImage: "arrow.up.right.square") }
                }
            }

            Section {
                if p == .custom {
                    TextField("Base URL (vd. https://…/v1)", text: $base)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .keyboardType(.URL)
                }
                TextField("Model", text: $model)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
            } header: {
                Text("Model")
            } footer: {
                Text("Tên model có thể đã thay đổi. Nếu báo lỗi 404, hãy xem danh sách model trên trang của nhà cung cấp và nhập tên đúng.")
            }

            Section {
                Button { test() } label: {
                    Label(testing ? "Đang thử…" : "Thử kết nối", systemImage: "bolt.horizontal.circle")
                }
                .disabled(testing || (key.isEmpty && p != .custom))
                if !testResult.isEmpty { Text(testResult).font(.footnote) }
            }
        }
        .scrollContentBackground(.hidden)
        .background { AuroraBackground(listening: false) }
        .navigationTitle(p.shortName)
        .navigationBarTitleDisplayMode(.inline)
        .onChange(of: key) { _, v in ProviderSettings.setKey(p, v) }
        .onChange(of: enabled) { _, v in ProviderSettings.setEnabled(p, v) }
        .onChange(of: model) { _, v in ProviderSettings.setModel(p, v) }
        .onChange(of: base) { _, v in ProviderSettings.setBase(p, v) }
    }

    private func test() {
        testing = true
        testResult = ""
        let m = model.trimmingCharacters(in: .whitespacesAndNewlines)
        let b = base.trimmingCharacters(in: .whitespacesAndNewlines)
        let cfg = ProviderConfig(id: p,
                                 key: key.trimmingCharacters(in: .whitespacesAndNewlines),
                                 model: m.isEmpty ? p.defaultModel : m,
                                 base: p == .custom ? b : p.defaultBase)
        Task {
            do {
                let r = try await LLM.complete(
                    cfg, system: "You are a translator. Reply with only the translation.",
                    messages: [(role: "user", text: "Translate to Vietnamese: hello, how are you today?")],
                    json: false, temperature: nil, timeout: 20)
                testResult = "✅ OK: \(r)"
            } catch {
                testResult = "❌ \(error.localizedDescription)"
            }
            testing = false
        }
    }
}
