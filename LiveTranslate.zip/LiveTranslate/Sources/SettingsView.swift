import SwiftUI

struct SettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var key = Keychain.get("geminiKey") ?? ""
    @AppStorage("geminiEnabled") private var enabled = true
    @AppStorage("geminiModel") private var model = AppSettings.defaultModel
    @State private var testResult = ""
    @State private var testing = false

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Toggle("Dùng Gemini", isOn: $enabled)
                        .tint(Color(r: 110, g: 90, b: 255))
                    SecureField("Dán API key (AIza…)", text: $key)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                    Button { if let s = UIPasteboard.general.string { key = s } } label: {
                        Label("Dán từ clipboard", systemImage: "doc.on.clipboard")
                    }
                    TextField("Model", text: $model)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                    Button { test() } label: {
                        Label(testing ? "Đang thử…" : "Thử kết nối", systemImage: "bolt.horizontal.circle")
                    }
                    .disabled(testing || key.isEmpty)
                    if !testResult.isEmpty { Text(testResult).font(.footnote) }
                } header: {
                    Text("Gemini • Google AI Studio")
                } footer: {
                    Text("Gemini giúp đoán đúng ngôn ngữ và dịch tự nhiên hơn. Key chỉ lưu trong Keychain trên iPhone này. Mỗi câu nói chỉ gửi chữ (không gửi âm thanh) lên Google. Lỗi hoặc hết hạn mức thì app tự dùng dịch offline của Apple.")
                }
            }
            .scrollContentBackground(.hidden)
            .background { AuroraBackground(listening: false) }
            .navigationTitle("Cài đặt")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Xong") { dismiss() } } }
            .onChange(of: key) { _, new in
                Keychain.set(new.trimmingCharacters(in: .whitespacesAndNewlines), for: "geminiKey")
            }
        }
        .preferredColorScheme(.dark)
        .presentationDragIndicator(.visible)
    }

    private func test() {
        testing = true
        testResult = ""
        let k = key.trimmingCharacters(in: .whitespacesAndNewlines)
        let m = model.trimmingCharacters(in: .whitespacesAndNewlines)
        Task {
            do {
                let r = try await GeminiClient.process(
                    candidates: [(lang: "en", text: "hello, how are you today"),
                                 (lang: "vi", text: "hê lô hao a du tu đây")],
                    context: [], key: k, model: m.isEmpty ? AppSettings.defaultModel : m)
                testResult = "✅ OK: \(r.translation)"
            } catch {
                testResult = "❌ \(error.localizedDescription)"
            }
            testing = false
        }
    }
}
