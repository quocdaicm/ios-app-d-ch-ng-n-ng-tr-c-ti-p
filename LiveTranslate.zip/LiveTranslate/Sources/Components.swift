import SwiftUI

// MARK: - Palette helper
extension Color {
    init(r: Double, g: Double, b: Double) { self.init(red: r / 255, green: g / 255, blue: b / 255) }
}

// MARK: - Aurora background
private func p(_ x: Double, _ y: Double) -> SIMD2<Float> { SIMD2<Float>(Float(x), Float(y)) }

struct AuroraBackground: View {
    var listening: Bool
    /// false = nền tĩnh (nhẹ máy hơn, dùng khi nhập chat).
    var animated: Bool = true

    var body: some View {
        Group {
            if animated {
                TimelineView(.animation(minimumInterval: 1.0 / 20.0)) { ctx in
                    mesh(ctx.date.timeIntervalSinceReferenceDate * (listening ? 0.55 : 0.25))
                }
            } else {
                mesh(0)
            }
        }
        .overlay(Color.black.opacity(0.22))
        .ignoresSafeArea()
    }

    private func mesh(_ t: Double) -> some View {
        let a = sin(t)
        let b = cos(t * 0.8)
        let c = sin(t * 1.3)
        return MeshGradient(
            width: 3, height: 3,
            points: [
                p(0, 0), p(0.5, 0), p(1, 0),
                p(0, 0.5 + 0.10 * a), p(0.5 + 0.15 * b, 0.5 + 0.12 * c), p(1, 0.5 - 0.10 * a),
                p(0, 1), p(0.5, 1), p(1, 1)
            ],
            colors: [
                Color(r: 6, g: 8, b: 24),    Color(r: 28, g: 22, b: 92),  Color(r: 6, g: 10, b: 28),
                Color(r: 66, g: 24, b: 120), listening ? Color(r: 40, g: 120, b: 245) : Color(r: 30, g: 78, b: 190),
                Color(r: 8, g: 90, b: 118),
                Color(r: 5, g: 7, b: 20),    Color(r: 4, g: 44, b: 70),   Color(r: 5, g: 8, b: 22)
            ]
        )
        .animation(.easeInOut(duration: 1.2), value: listening)
    }
}

// MARK: - Buttons
struct PressScale: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.93 : 1)
            .animation(.spring(response: 0.3, dampingFraction: 0.6), value: configuration.isPressed)
    }
}

struct GlassIcon: View {
    let icon: String
    @Environment(\.isEnabled) private var enabled

    var body: some View {
        Image(systemName: icon)
            .font(.system(size: 18, weight: .medium))
            .foregroundStyle(.white)
            .frame(width: 50, height: 50)
            .background(.ultraThinMaterial, in: Circle())
            .overlay(Circle().strokeBorder(.white.opacity(0.18), lineWidth: 1))
            .opacity(enabled ? 1 : 0.35)
    }
}

// MARK: - Segmented control
struct GlassSegmented<Item: Hashable>: View {
    let items: [Item]
    let title: (Item) -> String
    @Binding var selection: Item
    var disabled: Bool = false
    @Namespace private var ns

    var body: some View {
        HStack(spacing: 0) {
            ForEach(items, id: \.self) { item in
                Text(title(item))
                    .font(.system(.footnote, design: .rounded).weight(.semibold))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 10)
                    .foregroundStyle(selection == item ? Color.white : Color.white.opacity(0.6))
                    .background {
                        if selection == item {
                            Capsule()
                                .fill(LinearGradient(colors: [Color(r: 70, g: 130, b: 255), Color(r: 130, g: 80, b: 255)],
                                                     startPoint: .leading, endPoint: .trailing))
                                .shadow(color: Color(r: 90, g: 100, b: 255).opacity(0.5), radius: 10, y: 3)
                                .matchedGeometryEffect(id: "sel", in: ns)
                        }
                    }
                    .contentShape(Capsule())
                    .onTapGesture {
                        withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) { selection = item }
                    }
            }
        }
        .padding(4)
        .background(.ultraThinMaterial, in: Capsule())
        .overlay(Capsule().strokeBorder(.white.opacity(0.15), lineWidth: 1))
        .opacity(disabled ? 0.5 : 1)
        .allowsHitTesting(!disabled)
    }
}

// MARK: - Status pill
struct StatusPill: View {
    var running: Bool
    var ai: String?

    var body: some View {
        HStack(spacing: 8) {
            ZStack {
                Circle().fill(running ? Color.red : Color.green).frame(width: 8, height: 8)
                if running {
                    TimelineView(.animation) { ctx in
                        let ph = ctx.date.timeIntervalSinceReferenceDate.truncatingRemainder(dividingBy: 1.2) / 1.2
                        Circle().stroke(Color.red.opacity(1 - ph), lineWidth: 2)
                            .frame(width: 8, height: 8).scaleEffect(1 + ph * 1.8)
                    }
                }
            }
            Text(running ? "Đang nghe" : "Sẵn sàng")
                .font(.system(.caption, design: .rounded).weight(.semibold))
            Text("•").foregroundStyle(.white.opacity(0.35))
            HStack(spacing: 3) {
                Image(systemName: ai != nil ? "sparkles" : "wifi.slash").font(.system(size: 10, weight: .bold))
                Text(ai ?? "Offline").font(.system(.caption, design: .rounded).weight(.semibold))
                Image(systemName: "chevron.down").font(.system(size: 8, weight: .bold))
            }
            .foregroundStyle(ai != nil ? Color(r: 150, g: 200, b: 255) : Color.white.opacity(0.6))
        }
        .foregroundStyle(.white)
        .padding(.horizontal, 12).padding(.vertical, 6)
        .background(.ultraThinMaterial, in: Capsule())
        .overlay(Capsule().strokeBorder(.white.opacity(0.15), lineWidth: 1))
    }
}

// MARK: - Mic orb + waveform
struct Waveform: View {
    var level: CGFloat
    private let weights: [CGFloat] = [0.4, 0.7, 1.0, 0.8, 1.0, 0.7, 0.4]

    var body: some View {
        HStack(spacing: 4) {
            ForEach(0..<weights.count, id: \.self) { i in
                Capsule().fill(.white)
                    .frame(width: 4, height: 6 + 34 * level * weights[i])
            }
        }
        .animation(.easeOut(duration: 0.1), value: level)
    }
}

struct MicOrb: View {
    var running: Bool
    @ObservedObject var meter: AudioMeter
    var action: () -> Void

    var body: some View {
        Button(action: action) {
            ZStack {
                if running {
                    TimelineView(.animation) { ctx in
                        let t = ctx.date.timeIntervalSinceReferenceDate
                        ZStack {
                            ForEach(0..<2, id: \.self) { i in
                                let ph = (t / 1.8 + Double(i) * 0.5).truncatingRemainder(dividingBy: 1)
                                Circle()
                                    .stroke(Color(r: 255, g: 90, b: 110).opacity((1 - ph) * 0.6), lineWidth: 2)
                                    .scaleEffect(1 + ph * 0.9)
                            }
                        }
                    }
                }
                Circle()
                    .fill(LinearGradient(
                        colors: running
                            ? [Color(r: 255, g: 94, b: 120), Color(r: 255, g: 140, b: 70)]
                            : [Color(r: 60, g: 190, b: 255), Color(r: 120, g: 80, b: 255)],
                        startPoint: .topLeading, endPoint: .bottomTrailing))
                    .overlay(Circle().strokeBorder(.white.opacity(0.35), lineWidth: 1.5))
                    .shadow(color: (running ? Color.red : Color.blue).opacity(0.55), radius: 26, y: 8)
                    .scaleEffect(1 + (running ? meter.level * 0.10 : 0))
                    .animation(.easeOut(duration: 0.1), value: meter.level)

                if running {
                    Waveform(level: meter.level)
                } else {
                    Image(systemName: "mic.fill")
                        .font(.system(size: 32, weight: .semibold))
                        .foregroundStyle(.white)
                }
            }
            .frame(width: 88, height: 88)
        }
        .buttonStyle(PressScale())
        .animation(.easeInOut(duration: 0.3), value: running)
    }
}

// MARK: - Bubble
struct TypingDots: View {
    var body: some View {
        TimelineView(.animation) { ctx in
            let t = ctx.date.timeIntervalSinceReferenceDate
            HStack(spacing: 5) {
                ForEach(0..<3, id: \.self) { i in
                    Circle().fill(.white).frame(width: 7, height: 7)
                        .opacity(0.25 + 0.75 * max(0, sin(t * 4 - Double(i) * 0.8)))
                }
            }
        }
        .frame(height: 26, alignment: .leading)
    }
}

struct BubbleView: View {
    let lang: String
    let original: String
    let translated: String?
    let live: Bool
    var onSpeak: (() -> Void)? = nil

    private var isVi: Bool { lang == "vi" }
    private var tint: [Color] {
        isVi ? [Color(r: 70, g: 140, b: 255), Color(r: 150, g: 90, b: 255)]
             : [Color(r: 40, g: 215, b: 170), Color(r: 40, g: 150, b: 220)]
    }
    private var shape: UnevenRoundedRectangle {
        UnevenRoundedRectangle(topLeadingRadius: 24,
                               bottomLeadingRadius: isVi ? 6 : 24,
                               bottomTrailingRadius: isVi ? 24 : 6,
                               topTrailingRadius: 24, style: .continuous)
    }

    var body: some View {
        HStack(spacing: 0) {
            if !isVi { Spacer(minLength: 40) }
            VStack(alignment: .leading, spacing: 8) {
                HStack(spacing: 6) {
                    Text(isVi ? "🇻🇳" : "🇬🇧")
                    Image(systemName: "arrow.right").font(.system(size: 9, weight: .bold))
                        .foregroundStyle(.white.opacity(0.5))
                    Text(isVi ? "🇬🇧" : "🇻🇳")
                    Spacer(minLength: 0)
                    if translated != nil, !live, let onSpeak {
                        Button(action: onSpeak) {
                            Image(systemName: "speaker.wave.2.fill")
                                .font(.system(size: 13))
                                .foregroundStyle(.white.opacity(0.75))
                                .frame(width: 34, height: 24)
                        }
                        .buttonStyle(.plain)
                    }
                    if live {
                        Text("ĐANG NÓI")
                            .font(.system(size: 9, weight: .heavy, design: .rounded))
                            .tracking(1)
                            .foregroundStyle(.white.opacity(0.7))
                    }
                }
                .font(.system(size: 13))

                if let t = translated {
                    Text(t)
                        .font(.system(.title3, design: .rounded).weight(.semibold))
                        .foregroundStyle(.white)
                        .contentTransition(.opacity)
                } else {
                    TypingDots()
                }

                Text(original)
                    .font(.system(.footnote, design: .rounded))
                    .foregroundStyle(.white.opacity(0.55))
            }
            .padding(16)
            .background { shape.fill(.ultraThinMaterial) }
            .overlay { shape.fill(LinearGradient(colors: tint.map { $0.opacity(0.26) },
                                                 startPoint: .topLeading, endPoint: .bottomTrailing)) }
            .overlay {
                shape.strokeBorder(
                    LinearGradient(colors: [.white.opacity(0.35), .white.opacity(0.05)],
                                   startPoint: .topLeading, endPoint: .bottomTrailing),
                    style: StrokeStyle(lineWidth: 1, dash: live ? [5, 4] : []))
            }
            .shadow(color: tint[0].opacity(0.18), radius: 14, y: 6)
            .opacity(live ? 0.85 : 1)
            .contextMenu {
                if let t = translated {
                    Button("Sao chép bản dịch", systemImage: "doc.on.doc") { UIPasteboard.general.string = t }
                }
                Button("Sao chép câu gốc", systemImage: "text.quote") { UIPasteboard.general.string = original }
            }
            if isVi { Spacer(minLength: 40) }
        }
    }
}

// MARK: - Empty state
struct EmptyState: View {
    var body: some View {
        VStack(spacing: 12) {
            ZStack {
                Circle()
                    .fill(LinearGradient(colors: [Color(r: 60, g: 190, b: 255), Color(r: 130, g: 80, b: 255)],
                                         startPoint: .topLeading, endPoint: .bottomTrailing))
                    .frame(width: 92, height: 92)
                    .shadow(color: Color(r: 100, g: 100, b: 255).opacity(0.6), radius: 28, y: 8)
                Image(systemName: "waveform.and.mic")
                    .font(.system(size: 38, weight: .medium))
                    .foregroundStyle(.white)
            }
            Text("Sẵn sàng dịch hội thoại")
                .font(.system(.title3, design: .rounded).weight(.bold))
                .foregroundStyle(.white)
            Text("Đặt điện thoại giữa hai người, bấm nút mic rồi cứ nói chuyện bình thường.")
                .font(.system(.callout, design: .rounded))
                .foregroundStyle(.white.opacity(0.65))
                .multilineTextAlignment(.center)
            HStack(spacing: 10) {
                chip("🇻🇳 Tiếng Việt")
                Image(systemName: "arrow.left.arrow.right").font(.caption).foregroundStyle(.white.opacity(0.5))
                chip("🇬🇧 English")
            }
            .padding(.top, 4)
            .frame(maxWidth: .infinity)
        }
        .padding(.horizontal, 32)
        .padding(.top, 16)
        .padding(.bottom, 8)
    }

    private func chip(_ s: String) -> some View {
        Text(s)
            .font(.system(.footnote, design: .rounded).weight(.semibold))
            .lineLimit(1)
            .minimumScaleFactor(0.8)
            .fixedSize(horizontal: false, vertical: true)
            .foregroundStyle(.white)
            .padding(.horizontal, 14).padding(.vertical, 8)
            .background(.ultraThinMaterial, in: Capsule())
            .overlay(Capsule().strokeBorder(.white.opacity(0.15), lineWidth: 1))
    }
}
