import Foundation

struct ChatMessage: Identifiable {
    let id = UUID()
    let role: String          // "user" hoặc "model"
    var text: String
    var isError = false
}

@MainActor
final class ChatStore: ObservableObject {
    @Published var messages: [ChatMessage] = []
    @Published var sending = false

    private let baseSystem = """
    Bạn là trợ lý tích hợp trong ứng dụng dịch hội thoại trực tiếp Việt–Anh. \
    Trả lời ngắn gọn, rõ ràng, thân thiện. Mặc định dùng tiếng Việt, \
    trừ khi người dùng viết bằng ngôn ngữ khác thì trả lời bằng ngôn ngữ đó. \
    Có thể dùng **in đậm** và danh sách gạch đầu dòng ngắn khi cần.
    """

    func send(_ text: String, context: String?) {
        let t = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !t.isEmpty, !sending else { return }
        messages.append(ChatMessage(role: "user", text: t))

        let providers = AppSettings.providers()
        guard !providers.isEmpty else {
            messages.append(ChatMessage(
                role: "model",
                text: "Chưa có nhà cung cấp AI nào được bật. Mở Cài đặt (⚙️) để nhập API key rồi thử lại.",
                isError: true))
            return
        }

        let history = messages.filter { !$0.isError }.map { (role: $0.role, text: $0.text) }
        var system = baseSystem
        if let c = context, !c.isEmpty {
            system += "\n\nĐây là cuộc hội thoại gần đây đang được dịch trực tiếp (mỗi dòng: [ngôn ngữ nói] câu gốc → bản dịch). Dùng nó làm ngữ cảnh khi người dùng hỏi:\n" + c
        }

        sending = true
        Task { [weak self] in
            do {
                let reply = try await Interpreter.chat(history: history, system: system,
                                                       providers: providers)
                self?.messages.append(ChatMessage(role: "model", text: reply))
            } catch {
                self?.messages.append(ChatMessage(role: "model",
                                                  text: error.localizedDescription, isError: true))
            }
            self?.sending = false
        }
    }

    func clear() { messages = [] }
}
